'use client';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Navigation } from "lucide-react";
import Image from "next/image";
import { getPlaceholderImage } from "@/lib/placeholder-images";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import { useCollection, useFirestore, useMemoFirebase, useUser, updateDocumentNonBlocking, addDocumentNonBlocking } from "@/firebase";
import { collection, query, where, doc } from "firebase/firestore";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { useState, useRef, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { DeliveryBackButton } from "@/components/shared/delivery-back-button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";

type Delivery = {
    id: string;
    customerId: string;
    shopOwnerId: string;
    shippingAddress: string;
    status: string;
    paymentMethod: string;
    deliveryOtp?: string;
};

export default function DeliveryDashboardPage() {
    const mapImage = getPlaceholderImage("map");
    const firestore = useFirestore();
    const { user } = useUser();
    const { toast } = useToast();
    const deliveryPersonId = user?.uid;

    const deliveriesQuery = useMemoFirebase(() => {
        if (!firestore || !deliveryPersonId) return null;
        return query(
            collection(firestore, 'orders'),
            where('members', 'array-contains', deliveryPersonId),
            where('status', 'in', ['Packed', 'Shipped', 'Delivered'])
        );
    }, [firestore, deliveryPersonId]);

    const { data: assignedDeliveries, isLoading } = useCollection<Delivery>(deliveriesQuery);

    const [otpValues, setOtpValues] = useState<Record<string, string>>({});
    const [isCameraDialogOpen, setIsCameraDialogOpen] = useState(false);
    const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
    const [selectedDelivery, setSelectedDelivery] = useState<Delivery | null>(null);
    const videoRef = useRef<HTMLVideoElement>(null);
    const streamRef = useRef<MediaStream | null>(null);

    useEffect(() => {
        const enableCamera = async () => {
            if (isCameraDialogOpen) {
                try {
                    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
                    streamRef.current = stream;
                    setHasCameraPermission(true);
                    if (videoRef.current) {
                        videoRef.current.srcObject = stream;
                    }
                } catch (error) {
                    console.error('Error accessing camera:', error);
                    setHasCameraPermission(false);
                    toast({
                        variant: 'destructive',
                        title: 'Camera Access Denied',
                        description: 'Please enable camera permissions in your browser settings to accept deliveries.',
                    });
                    setIsCameraDialogOpen(false); // Close dialog if permission denied
                }
            } else {
                // Stop camera when dialog is closed
                if (streamRef.current) {
                    streamRef.current.getTracks().forEach(track => track.stop());
                    streamRef.current = null;
                }
            }
        };

        enableCamera();

        // Cleanup function to stop camera when component unmounts while dialog is open
        return () => {
            if (streamRef.current) {
                streamRef.current.getTracks().forEach(track => track.stop());
            }
        };
    }, [isCameraDialogOpen, toast]);

    const handleAcceptClick = (delivery: Delivery) => {
        setSelectedDelivery(delivery);
        setIsCameraDialogOpen(true);
    };

    const handleConfirmAcceptance = () => {
        if (selectedDelivery) {
            handleStatusUpdate(selectedDelivery, 'Shipped');
        }
        setIsCameraDialogOpen(false);
    };

    const handleOtpChange = (orderId: string, value: string) => {
        setOtpValues(prev => ({ ...prev, [orderId]: value }));
    };

    const createNotification = (userId: string, message: string, link: string) => {
        if (!firestore) return;
        const notificationsCollection = collection(firestore, 'notifications');
        addDocumentNonBlocking(notificationsCollection, {
            userId,
            message,
            link,
            read: false,
            createdAt: new Date().toISOString(),
        });
    };

    const handleConfirmDelivery = (delivery: Delivery) => {
        const enteredOtp = otpValues[delivery.id];
        if (!enteredOtp || enteredOtp.length !== 6) {
            toast({ variant: 'destructive', title: 'Invalid OTP', description: 'Please enter the 6-digit OTP.' });
            return;
        }

        if (enteredOtp === delivery.deliveryOtp) {
            if (!firestore) return;
            const orderRef = doc(firestore, 'orders', delivery.id);
            updateDocumentNonBlocking(orderRef, { status: 'Delivered' });

            toast({ title: 'Delivery Confirmed!', description: 'Order has been marked as delivered.' });
            createNotification(delivery.customerId, `Your order #${delivery.id.substring(0, 6)} has been delivered!`, `/orders/${delivery.id}`);
            createNotification(delivery.shopOwnerId, `Order #${delivery.id.substring(0, 6)} was successfully delivered.`, `/seller/orders/${delivery.id}`);
            
        } else {
            toast({ variant: 'destructive', title: 'Incorrect OTP', description: 'The OTP does not match. Please try again.' });
        }
    };
    
    const handleStatusUpdate = (delivery: Delivery, status: 'Packed' | 'Shipped') => {
        if (!firestore) return;
        const orderRef = doc(firestore, 'orders', delivery.id);
        updateDocumentNonBlocking(orderRef, { status });
        toast({ title: 'Status Updated', description: `Order marked as ${status}.`});

        if (status === 'Shipped') {
            createNotification(delivery.customerId, `Your order #${delivery.id.substring(0, 6)} is on the way!`, `/orders/${delivery.id}`);
        }
    };


    const getDirectionsUrl = (origin: string, destination: string) => {
        const googleMapsUrl = new URL('https://www.google.com/maps/dir/');
        googleMapsUrl.searchParams.append('api', '1');
        googleMapsUrl.searchParams.append('origin', origin);
        googleMapsUrl.searchParams.append('destination', destination);
        googleMapsUrl.searchParams.append('travelmode', 'driving');
        return googleMapsUrl.toString();
    }

    return (
        <>
        <div>
            <h1 className="text-2xl font-headline font-bold mb-4">Assigned Deliveries</h1>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-4">
                    {isLoading && (
                        <>
                           <Card><CardContent className="p-6"><Skeleton className="h-48" /></CardContent></Card>
                           <Card><CardContent className="p-6"><Skeleton className="h-48" /></CardContent></Card>
                        </>
                    )}
                    {assignedDeliveries?.map(delivery => (
                        <Card key={delivery.id}>
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <div>
                                        <CardTitle>Order #{delivery.id.substring(0,6)}</CardTitle>
                                        <CardDescription>Customer: {delivery.customerId.substring(0,6)}</CardDescription>
                                    </div>
                                    <Badge variant={delivery.status === 'Packed' ? 'secondary' : delivery.status === 'Delivered' ? 'default' : 'outline'}>{delivery.status}</Badge>
                                </div>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="space-y-2">
                                    <h4 className="font-semibold flex items-center gap-2"><MapPin className="h-4 w-4 text-muted-foreground"/> Pickup From</h4>
                                    <p className="text-sm">Shop: {delivery.shopOwnerId.substring(0,6)}</p>
                                    <p className="text-sm text-muted-foreground">Shop Address Placeholder</p>
                                </div>
                                <div className="space-y-2">
                                    <h4 className="font-semibold flex items-center gap-2"><MapPin className="h-4 w-4 text-muted-foreground"/> Deliver To</h4>
                                    <p className="text-sm">{delivery.shippingAddress}</p>
                                </div>
                                {delivery.status === 'Shipped' && (
                                <div>
                                    <h4 className="font-semibold">OTP Verification</h4>
                                     <div className="flex gap-2 mt-2">
                                        <Input 
                                            type="text" 
                                            placeholder="Enter 6-digit OTP"
                                            maxLength={6}
                                            value={otpValues[delivery.id] || ''}
                                            onChange={(e) => handleOtpChange(delivery.id, e.target.value)}
                                        />
                                        <Button onClick={() => handleConfirmDelivery(delivery)}>Confirm Delivery</Button>
                                    </div>
                                </div>
                                )}
                            </CardContent>
                            <CardFooter className="flex gap-2">
                                {delivery.status === 'Packed' && (
                                    <Button variant="outline" size="sm" onClick={() => handleAcceptClick(delivery)}>
                                        Accept Delivery
                                    </Button>
                                )}
                                {(delivery.status === 'Packed' || delivery.status === 'Shipped') && (
                                    <Button asChild variant="secondary" className="ml-auto" size="sm">
                                        <Link href={getDirectionsUrl("Shop Address", delivery.shippingAddress)} target="_blank" rel="noopener noreferrer">
                                            <Navigation className="h-4 w-4 mr-2" />
                                            Navigate
                                        </Link>
                                    </Button>
                                )}
                                {delivery.status === 'Delivered' && (
                                    <p className="text-sm text-green-600 font-semibold">Delivery Completed</p>
                                )}
                            </CardFooter>
                        </Card>
                    ))}
                    {!isLoading && assignedDeliveries?.length === 0 && (
                        <Card>
                            <CardContent className="p-12 text-center text-muted-foreground">
                                <p>You have no active deliveries.</p>
                            </CardContent>
                        </Card>
                    )}
                </div>
                <div className="hidden lg:block">
                     <Card className="h-full">
                        <CardHeader>
                            <CardTitle>Delivery Zone</CardTitle>
                            <CardDescription>An overview of your current delivery locations.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="aspect-video relative rounded-lg overflow-hidden">
                                <Image src={mapImage.imageUrl} alt="Map of delivery zone" fill className="object-cover" data-ai-hint={mapImage.imageHint} />
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>

        <Dialog open={isCameraDialogOpen} onOpenChange={setIsCameraDialogOpen}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Confirm Your Identity</DialogTitle>
                    <DialogDescription>
                        Please show your face to the camera to confirm you are starting the delivery.
                    </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                    <div className="relative aspect-video w-full bg-muted rounded-md overflow-hidden">
                        <video ref={videoRef} className="w-full h-full object-cover" autoPlay muted playsInline />
                    </div>
                    {hasCameraPermission === false && (
                        <Alert variant="destructive">
                            <AlertTitle>Camera Access Required</AlertTitle>
                            <AlertDescription>
                                Please allow camera access in your browser settings to use this feature.
                            </AlertDescription>
                        </Alert>
                    )}
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => setIsCameraDialogOpen(false)}>Cancel</Button>
                    <Button onClick={handleConfirmAcceptance} disabled={!hasCameraPermission}>Confirm and Start Delivery</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
      </>
    );
}
    
