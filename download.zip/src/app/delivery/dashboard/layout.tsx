'use client';
import Link from "next/link";
import {
  Package,
  CircleDollarSign,
  Menu,
  Settings,
  MapPin,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { UserNav } from "@/components/layout/user-nav";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Logo } from "@/components/shared/logo";
import { ModeToggle } from "@/components/dark-mode-toggle";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Notifications } from "@/components/layout/notifications";
import { useCollection, useDoc, useFirestore, useUser, useMemoFirebase, setDocumentNonBlocking } from "@/firebase";
import { collection, doc, query, where } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";

export default function DeliveryDashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const firestore = useFirestore();
  const { user } = useUser();
  const { toast } = useToast();
  const deliveryPersonId = user?.uid;

  const ordersQuery = useMemoFirebase(() => {
    if (!firestore || !deliveryPersonId) return null;
    return query(
      collection(firestore, "orders"),
      where("members", "array-contains", deliveryPersonId)
    );
  }, [firestore, deliveryPersonId]);
  
  const { data: orders } = useCollection(ordersQuery);

  const navLinks = [
    { href: "/delivery/dashboard", label: "Assigned Orders", icon: Package, badge: orders?.length.toString() },
    { href: "/delivery/earnings", label: "Earnings", icon: CircleDollarSign },
    { href: "/delivery/settings", label: "Settings", icon: Settings },
  ];

  const deliveryPersonRef = useMemoFirebase(() => {
    if (!firestore || !deliveryPersonId) return null;
    return doc(firestore, 'deliveryPersons', deliveryPersonId);
  }, [firestore, deliveryPersonId]);

  const { data: deliveryPerson, isLoading: isDeliveryPersonLoading } = useDoc(deliveryPersonRef);
  
  const [isOnline, setIsOnline] = useState(false);
  const [initialStateSet, setInitialStateSet] = useState(false);

  useEffect(() => {
    // Only set the initial state from the database when data first arrives.
    if (deliveryPerson && !isDeliveryPersonLoading && !initialStateSet) {
      setIsOnline(deliveryPerson.online ?? false);
      setInitialStateSet(true);
    }
  }, [deliveryPerson, isDeliveryPersonLoading, initialStateSet]);

  const handleOnlineToggle = (online: boolean) => {
    if (!deliveryPersonRef) return;

    // 1. Update the local state immediately for instant UI feedback.
    setIsOnline(online);
    
    // 2. Send the update to the database in the background.
    setDocumentNonBlocking(deliveryPersonRef, { online: online }, { merge: true });
    
    toast({
        title: `You are now ${online ? 'Online' : 'Offline'}`,
        description: online ? 'You will be shown available for new deliveries.' : 'You will not receive new delivery tasks.',
    });
  };

  const handleShareLocation = () => {
    if (!deliveryPersonRef) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not share location. User not found.",
      });
      return;
    }
    
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                const locationString = `Lat: ${latitude.toFixed(4)}, Lng: ${longitude.toFixed(4)}`;
                setDocumentNonBlocking(deliveryPersonRef, { location: locationString }, { merge: true });
                toast({
                    title: "Location Shared",
                    description: "Your current location has been updated.",
                });
            },
            (error) => {
                console.error("Geolocation error:", error);
                toast({
                    variant: "destructive",
                    title: "Location Error",
                    description: "Could not retrieve your location.",
                });
            }
        );
    } else {
        toast({
            variant: "destructive",
            title: "Unsupported",
            description: "Your browser does not support geolocation.",
        });
    }
  };

  return (
    <div className="grid min-h-screen w-full md:grid-cols-[220px_1fr] lg:grid-cols-[280px_1fr]">
      <div className="hidden border-r bg-muted/40 md:block">
        <div className="flex h-full max-h-screen flex-col gap-2">
          <div className="flex h-16 items-center border-b px-6">
            <Logo />
          </div>
          <div className="flex-1">
            <nav className="grid items-start px-4 text-sm font-medium">
              {navLinks.map(link => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <link.icon className="h-4 w-4" />
                  {link.label}
                  {link.badge && link.badge !== '0' && <Badge className="ml-auto flex h-6 w-6 shrink-0 items-center justify-center rounded-full">{link.badge}</Badge>}
                </Link>
              ))}
            </nav>
            <div className="px-4 mt-4">
              <Button variant="outline" className="w-full" onClick={handleShareLocation}>
                <MapPin className="mr-2 h-4 w-4" />
                Share My Location
              </Button>
            </div>
          </div>
          <div className="mt-auto p-4 border-t">
            <div className="flex items-center justify-between">
                <Label htmlFor="online-status" className="flex items-center gap-2">
                    Online Status
                </Label>
              <Switch id="online-status" checked={isOnline} onCheckedChange={handleOnlineToggle} disabled={isDeliveryPersonLoading} />
            </div>
          </div>
        </div>
      </div>
      <div className="flex flex-col">
        <header className="flex h-14 items-center gap-4 border-b bg-muted/40 px-4 lg:h-[60px] lg:px-6">
          <Sheet>
            <SheetTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="shrink-0 md:hidden"
              >
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle navigation menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="flex flex-col">
              <nav className="grid gap-2 text-lg font-medium">
                <div className="mb-4">
                  <Logo />
                </div>
                {navLinks.map(link => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="flex items-center gap-4 rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground"
                >
                  <link.icon className="h-5 w-5" />
                  {link.label}
                  {link.badge && link.badge !== '0' && <Badge className="ml-auto flex h-6 w-6 shrink-0 items-center justify-center rounded-full">{link.badge}</Badge>}
                </Link>
              ))}
              </nav>
              <div className="px-4 mt-4">
                <Button variant="outline" className="w-full" onClick={handleShareLocation}>
                  <MapPin className="mr-2 h-4 w-4" />
                  Share My Location
                </Button>
            </div>
               <div className="mt-auto p-4 border-t">
                 <div className="flex items-center justify-between">
                    <Label htmlFor="online-status-mobile" className="flex items-center gap-2">
                        Online Status
                    </Label>
                  <Switch id="online-status-mobile" checked={isOnline} onCheckedChange={handleOnlineToggle} disabled={isDeliveryPersonLoading} />
                </div>
              </div>
            </SheetContent>
          </Sheet>
          <div className="w-full flex-1">
             <h1 className="font-semibold text-lg">Delivery Dashboard</h1>
          </div>
          <Notifications />
          <ModeToggle />
          <UserNav />
        </header>
        <main className="flex flex-1 flex-col gap-4 p-4 lg:gap-6 lg:p-6 bg-background">
            {children}
        </main>
      </div>
    </div>
  );
}
