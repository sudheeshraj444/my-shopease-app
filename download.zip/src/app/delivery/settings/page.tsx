'use client';
import { useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useDoc, useFirestore, useUser, setDocumentNonBlocking, useMemoFirebase } from '@/firebase';
import { doc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { DeliveryBackButton } from '@/components/shared/delivery-back-button';

const profileSchema = z.object({
  vehicleNumber: z.string().min(1, 'Vehicle number is required'),
  location: z.string().optional(),
});

type ProfileFormData = z.infer<typeof profileSchema>;

export default function DeliverySettingsPage() {
  const firestore = useFirestore();
  const { user } = useUser();
  const { toast } = useToast();
  const deliveryPersonId = user?.uid;

  const deliveryPersonRef = useMemoFirebase(() => {
    if (!firestore || !deliveryPersonId) return null;
    return doc(firestore, 'deliveryPersons', deliveryPersonId);
  }, [firestore, deliveryPersonId]);

  const { data: deliveryPerson, isLoading } = useDoc(deliveryPersonRef);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isDirty },
  } = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
  });

  useEffect(() => {
    if (deliveryPerson) {
      reset({
        vehicleNumber: deliveryPerson.vehicleNumber || '',
        location: deliveryPerson.location || 'Not shared yet',
      });
    }
  }, [deliveryPerson, reset]);

  const onSubmit = (data: ProfileFormData) => {
    if (!deliveryPersonRef) return;
    // We only want to submit the vehicle number from this form
    setDocumentNonBlocking(deliveryPersonRef, { vehicleNumber: data.vehicleNumber }, { merge: true });
    toast({
      title: 'Profile Updated',
      description: 'Your vehicle information has been saved.',
    });
  };

  return (
    <div>
      <div className="flex items-center gap-4 mb-4">
        <DeliveryBackButton />
        <h1 className="text-2xl font-headline font-bold">My Settings</h1>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Profile Information</CardTitle>
          <CardDescription>Update your personal details here.</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
                <Skeleton className="h-10" />
                <Skeleton className="h-10" />
                <Skeleton className="h-10" />
                 <Skeleton className="h-10 w-32" />
            </div>
          ) : (
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" type="tel" defaultValue={user?.phoneNumber || 'Not available'} disabled />
              </div>
               <div className="space-y-2">
                <Label htmlFor="vehicleNumber">Vehicle Number</Label>
                <Input id="vehicleNumber" {...register('vehicleNumber')} />
                {errors.vehicleNumber && <p className="text-sm text-destructive">{errors.vehicleNumber.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="location">Last Shared Location</Label>
                <Input id="location" {...register('location')} disabled />
              </div>
              <Button type="submit" disabled={!isDirty}>Save Changes</Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
