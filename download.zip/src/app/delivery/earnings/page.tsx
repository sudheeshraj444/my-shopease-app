import { DeliveryBackButton } from "@/components/shared/delivery-back-button";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export default function DeliveryEarningsPage() {
  return (
    <div>
        <div className="flex items-center gap-4 mb-4">
            <DeliveryBackButton />
            <h1 className="text-2xl font-headline font-bold">My Earnings</h1>
        </div>
      <Card>
        <CardHeader>
          <CardTitle>Weekly Payouts & Bonuses</CardTitle>
          <CardDescription>Your per-delivery earnings, bonuses, and weekly payout details will be displayed here.</CardDescription>
        </CardHeader>
        {/* Earnings details will go here */}
      </Card>
    </div>
  );
}
