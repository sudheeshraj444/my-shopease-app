'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { User, Building2, Truck, Loader2 } from 'lucide-react';
import { Logo } from '@/components/shared/logo';
import { useUser, useFirestore, setDocumentNonBlocking } from '@/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { useCartStore } from '@/lib/cart-store';

const roles = [
  {
    name: 'Customer',
    icon: <User className="h-12 w-12 mb-4 text-primary" />,
    href: '/',
    collectionName: 'customers'
  },
  {
    name: 'Shop Owner',
    icon: <Building2 className="h-12 w-12 mb-4 text-primary" />,
    href: '/seller/dashboard',
    collectionName: 'shopOwners'
  },
  {
    name: 'Delivery Person',
    icon: <Truck className="h-12 w-12 mb-4 text-primary" />,
    href: '/delivery/dashboard',
    collectionName: 'deliveryPersons'
  },
];

export default function SelectRolePage() {
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();
  const router = useRouter();
  const { redirectUrl, setRedirectUrl } = useCartStore();
  const [isLoading, setIsLoading] = useState(true);
  const [showRoleSelection, setShowRoleSelection] = useState(false);

  useEffect(() => {
    const checkForExistingRole = async () => {
      // This function will only run when we know the user's auth state for sure.
      if (!isUserLoading && user && firestore) {
        const roleChecks = roles.map(role => 
            getDoc(doc(firestore, role.collectionName, user.uid))
        );
        const results = await Promise.all(roleChecks);
        
        const existingRoleIndex = results.findIndex(result => result.exists());

        if (existingRoleIndex !== -1) {
            // A role was found, redirect.
            const finalRedirect = redirectUrl || roles[existingRoleIndex].href;
            setRedirectUrl(null);
            router.replace(finalRedirect);
        } else {
            // No roles found, explicitly show the selection screen.
            setShowRoleSelection(true);
            setIsLoading(false);
        }
      } else if (!isUserLoading && !user) {
        // If auth check is done and there's no user, go to login.
        router.replace('/login');
      }
    };

    checkForExistingRole();
    // We only want this to run when the user/loading state changes.
  }, [user, isUserLoading, firestore]);


  const handleRoleSelection = async (collectionName: string, href: string) => {
      if (!user || !firestore) return;
      setIsLoading(true);

      const userDocRef = doc(firestore, collectionName, user.uid);
      
      // Basic data to initialize the user profile
      const initialData: { id: string; phoneNumber: string | null } = {
          id: user.uid,
          phoneNumber: user.phoneNumber,
      };

      setDocumentNonBlocking(userDocRef, initialData, { merge: true });
      
      // Redirect to the selected dashboard or the saved URL
      const finalRedirect = redirectUrl || href;
      setRedirectUrl(null); // Clear the redirect URL
      router.replace(finalRedirect);
  };


  if (isLoading) {
      return (
          <div className="flex min-h-screen flex-col items-center justify-center bg-background p-4">
              <Loader2 className="h-12 w-12 animate-spin text-primary" />
              <p className="mt-4 text-muted-foreground">Checking your account...</p>
          </div>
      )
  }

  if (showRoleSelection) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-background p-4">
        <div className="absolute top-8 left-8">
          <Logo />
        </div>
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold font-headline">Welcome! Select Your Role</h1>
          <p className="text-muted-foreground">Choose how you want to use ShopEase.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {roles.map((role) => (
            <Card 
                key={role.name}
                className="w-64 h-64 flex flex-col items-center justify-center text-center transition-all hover:shadow-xl hover:-translate-y-2 hover:border-primary cursor-pointer"
                onClick={() => handleRoleSelection(role.collectionName, role.href)}
            >
              <CardHeader className="flex flex-col items-center">
                {role.icon}
                <CardTitle className="font-headline">{role.name}</CardTitle>
              </CardHeader>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  // Fallback, should not be reached if logic is correct
  return null;
}
