'use client';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { ProductCard } from '@/components/shared/product-card';
import { useCollection, useFirestore, useMemoFirebase } from '@/firebase';
import { collection, query, where } from 'firebase/firestore';
import type { Product } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { getPlaceholderImage } from '@/lib/placeholder-images';
import { Package } from 'lucide-react';
import { BackButton } from '@/components/shared/back-button';

export default function CategoryProductsPage({ params }: { params: { categoryId: string } }) {
    const firestore = useFirestore();

    // Query the top-level 'products' collection, filtering by the category from the URL.
    const productsQuery = useMemoFirebase(() => {
        if (!firestore) return null;
        return query(collection(firestore, 'products'), where('category', '==', params.categoryId));
    }, [firestore, params.categoryId]);

    const { data: products, isLoading } = useCollection<Omit<Product, 'rating' | 'reviewCount'>>(productsQuery);

    return (
        <div className="flex min-h-screen flex-col">
            <Header />
            <main className="flex-1 bg-muted/40">
                <div className="container mx-auto py-8">
                    <div className="flex items-center gap-4 mb-6">
                        <BackButton />
                         <h1 className="text-3xl font-bold font-headline capitalize">
                            {decodeURIComponent(params.categoryId)}
                        </h1>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {isLoading && Array.from({ length: 4 }).map((_, i) => (
                            <Card key={i}>
                                <CardContent className="p-0">
                                    <Skeleton className="w-full h-48" />
                                </CardContent>
                                <CardFooter className="flex-col items-start p-4">
                                    <Skeleton className="h-6 w-3/4 mb-2" />
                                    <Skeleton className="h-4 w-1/2" />
                                </CardFooter>
                            </Card>
                        ))}
                        
                        {!isLoading && products?.map((product) => {
                            const displayProduct: Product = {
                                ...product,
                                rating: 4.5 + Math.random() * 0.5,
                                reviewCount: Math.floor(Math.random() * 1000) + 50,
                                image: product.images?.[0] || getPlaceholderImage('product-1').imageUrl,
                                imageHint: 'product',
                            }
                            return <ProductCard key={product.id} product={displayProduct} />
                        })}
                    </div>

                    {!isLoading && (!products || products.length === 0) && (
                        <div className="col-span-full flex flex-col items-center justify-center text-center text-muted-foreground p-12 border-2 border-dashed rounded-lg">
                            <Package className="h-16 w-16 mb-4" />
                            <p className="font-semibold">No products found in this category yet.</p>
                            <p className="text-sm">Check back later or browse other categories!</p>
                        </div>
                    )}
                </div>
            </main>
            <Footer />
        </div>
    );
}
