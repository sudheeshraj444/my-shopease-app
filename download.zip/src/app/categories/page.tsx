'use client';
import Image from 'next/image';
import Link from 'next/link';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { getPlaceholderImage } from '@/lib/placeholder-images';
import type { Category } from '@/lib/types';

const mockCategories: Category[] = [
    { id: 'fashion', name: 'Fashion', image: getPlaceholderImage('category-fashion').imageUrl, imageHint: getPlaceholderImage('category-fashion').imageHint },
    { id: 'electronics', name: 'Electronics', image: getPlaceholderImage('category-electronics').imageUrl, imageHint: getPlaceholderImage('category-electronics').imageHint },
    { id: 'home', name: 'Home', image: getPlaceholderImage('category-home').imageUrl, imageHint: getPlaceholderImage('category-home').imageHint },
    { id: 'grocery', name: 'Grocery', image: getPlaceholderImage('category-grocery').imageUrl, imageHint: getPlaceholderImage('category-grocery').imageHint },
    { id: 'beauty', name: 'Beauty', image: getPlaceholderImage('category-beauty').imageUrl, imageHint: getPlaceholderImage('category-beauty').imageHint },
    { id: 'toys', name: 'Toys', image: getPlaceholderImage('category-toys').imageUrl, imageHint: getPlaceholderImage('category-toys').imageHint },
];

export default function CategoriesPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 bg-muted/40">
        <div className="container mx-auto py-8">
          <h1 className="text-3xl font-bold font-headline mb-6">Shop by Category</h1>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
            {mockCategories.map((category) => (
              <Link href={`/categories/${category.id}`} key={category.id} className="group flex flex-col items-center gap-2 text-center bg-card p-4 rounded-lg shadow-sm transition-all hover:shadow-md">
                <div className="w-28 h-28 relative rounded-full overflow-hidden border-2 border-transparent group-hover:border-primary transition-colors">
                  <Image src={category.image} alt={category.name} fill className="object-cover" data-ai-hint={category.imageHint} />
                </div>
                <span className="font-semibold text-md mt-2">{category.name}</span>
              </Link>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
