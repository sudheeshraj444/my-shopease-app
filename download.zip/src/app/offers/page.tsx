import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tag } from "lucide-react";

export default function OffersPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 bg-muted/40">
        <div className="container mx-auto py-8">
          <h1 className="text-3xl font-bold font-headline mb-6">Special Offers</h1>
            <Card>
                <CardHeader>
                    <CardTitle>Current Promotions</CardTitle>
                    <CardDescription>Check back soon for exciting deals and discounts!</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="flex flex-col items-center justify-center text-center text-muted-foreground p-12 border-2 border-dashed rounded-lg">
                        <Tag className="h-16 w-16 mb-4" />
                        <p className="font-semibold">No offers available at the moment.</p>
                    </div>
                </CardContent>
            </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}
