
import { SellerBackButton } from "@/components/shared/seller-back-button";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export default function SellerEarningsPage() {
  return (
    <div>
       <div className="flex items-center gap-4 mb-4">
        <SellerBackButton />
        <h1 className="text-2xl font-headline font-bold">Earnings</h1>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Payouts & History</CardTitle>
          <CardDescription>Your earnings, commission deductions, and payout history will be shown here.</CardDescription>
        </CardHeader>
        {/* Earnings details will go here */}
      </Card>
    </div>
  );
}
