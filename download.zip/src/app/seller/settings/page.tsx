'use client';
import { useEffect, useState, useRef } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useDoc, useFirestore, useUser, setDocumentNonBlocking, useMemoFirebase } from '@/firebase';
import { doc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { SellerBackButton } from '@/components/shared/seller-back-button';
import { MapPin, Upload } from 'lucide-react';
import Image from 'next/image';
import { getPlaceholderImage } from '@/lib/placeholder-images';

const settingsSchema = z.object({
  shopName: z.string().min(1, 'Shop name is required'),
  address: z.string().optional(),
  location: z.string().optional(),
  shopImageUrl: z.string().url().optional().or(z.literal('')),
});

type SettingsFormData = z.infer<typeof settingsSchema>;

export default function SellerSettingsPage() {
  const firestore = useFirestore();
  const { user } = useUser();
  const { toast } = useToast();
  const shopOwnerId = user?.uid;
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const shopOwnerRef = useMemoFirebase(() => {
    if (!firestore || !shopOwnerId) return null;
    return doc(firestore, 'shopOwners', shopOwnerId);
  }, [firestore, shopOwnerId]);

  const { data: shopOwner, isLoading } = useDoc(shopOwnerRef);

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    watch,
    formState: { errors, isDirty },
  } = useForm<SettingsFormData>({
    resolver: zodResolver(settingsSchema),
  });

  const shopImageUrl = watch('shopImageUrl');

  useEffect(() => {
    if (shopOwner) {
      reset({
        shopName: shopOwner.shopName || '',
        address: shopOwner.address || '',
        location: shopOwner.location || '',
        shopImageUrl: shopOwner.shopImageUrl || '',
      });
    }
  }, [shopOwner, reset]);

  const handleImageClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setImagePreview(result);
        // NOTE: In a real app, you would upload this file to a service like
        // Firebase Storage, get the public URL, and then set that URL here.
        // For now, we'll use a placeholder URL to demonstrate the flow.
        const placeholderUrl = getPlaceholderImage('product-1').imageUrl;
        setValue('shopImageUrl', placeholderUrl, { shouldDirty: true });
        toast({
          title: 'Image Selected',
          description: 'Click "Save Changes" to apply. This is a preview only.',
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = (data: SettingsFormData) => {
    if (!shopOwnerRef) return;
    setDocumentNonBlocking(shopOwnerRef, data, { merge: true });
    toast({
      title: 'Settings Updated',
      description: 'Your shop information has been saved.',
    });
  };

  const handleLocationClick = () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                const locationString = `Lat: ${latitude.toFixed(4)}, Lng: ${longitude.toFixed(4)}`;
                setValue('location', locationString, { shouldValidate: true, shouldDirty: true });
                toast({
                    title: "Location Fetched",
                    description: "Your current location has been set.",
                });
            },
            (error) => {
                console.error("Geolocation error:", error);
                toast({
                    variant: "destructive",
                    title: "Location Error",
                    description: "Could not retrieve your location. Please enter it manually.",
                });
            }
        );
    } else {
        toast({
            variant: "destructive",
            title: "Unsupported",
            description: "Your browser does not support geolocation.",
        });
    }
  };
  
  const displayImage = imagePreview || shopImageUrl || getPlaceholderImage('category-home').imageUrl;

  return (
    <div>
      <div className="flex items-center gap-4 mb-4">
        <SellerBackButton />
        <h1 className="text-2xl font-headline font-bold">Shop Settings</h1>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Shop Information</CardTitle>
          <CardDescription>Update your shop details and location here.</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-10" />
              <Skeleton className="h-10" />
              <Skeleton className="h-24" />
              <Skeleton className="h-10 w-32" />
            </div>
          ) : (
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">

            <div className="space-y-2">
                <Label>Shop Image</Label>
                <div className="relative w-32 h-32 cursor-pointer group" onClick={handleImageClick}>
                    <Image
                        src={displayImage}
                        alt="Shop Image"
                        fill
                        className="rounded-full object-cover border-4 border-background group-hover:border-primary transition-colors"
                    />
                    <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Upload className="h-8 w-8 text-white" />
                    </div>
                </div>
                 <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    className="hidden"
                    accept="image/png, image/jpeg, image/gif"
                />
            </div>


              <div className="space-y-2">
                <Label htmlFor="shopName">Shop Name</Label>
                <Input id="shopName" {...register('shopName')} />
                {errors.shopName && <p className="text-sm text-destructive">{errors.shopName.message}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Address</Label>
                <Input id="address" {...register('address')} />
                {errors.address && <p className="text-sm text-destructive">{errors.address.message}</p>}
              </div>
              
              <div className="space-y-2">
                 <div className="flex justify-between items-center">
                    <Label htmlFor="location">GPS Location</Label>
                    <Button type="button" variant="outline" size="sm" onClick={handleLocationClick}>
                        <MapPin className="mr-2 h-4 w-4"/>
                        Use My Location
                    </Button>
                </div>
                <Input id="location" {...register('location')} disabled />
              </div>

              <Button type="submit" disabled={!isDirty}>Save Changes</Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
