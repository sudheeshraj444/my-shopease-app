
import { AddProductForm } from "@/components/seller/add-product-form";
import { SellerBackButton } from "@/components/shared/seller-back-button";

export default function AddProductPage() {
    return (
        <div>
            <div className="flex items-center gap-4 mb-4">
                <SellerBackButton />
                <h1 className="text-2xl font-headline font-bold">Add a New Product</h1>
            </div>
            <AddProductForm />
        </div>
    )
}
