'use client';
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { PlusCircle } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import Image from "next/image";
import { useCollection, useFirestore, useUser, useMemoFirebase, updateDocumentNonBlocking } from "@/firebase";
import { collection, query, doc } from "firebase/firestore";
import { Skeleton } from "@/components/ui/skeleton";
import { getPlaceholderImage } from "@/lib/placeholder-images";
import { useToast } from "@/hooks/use-toast";
import { SellerBackButton } from "@/components/shared/seller-back-button";

export default function SellerProductsPage() {
    const firestore = useFirestore();
    const { user } = useUser();
    const { toast } = useToast();
    const shopOwnerId = user?.uid;

    const productsQuery = useMemoFirebase(() => {
        if (!firestore || !shopOwnerId) return null;
        // The collection path must match Firestore rules for sellers.
        return query(collection(firestore, `shops/${shopOwnerId}/products`));
    }, [firestore, shopOwnerId]);

    const { data: products, isLoading } = useCollection(productsQuery);

    const handleStockToggle = (product: {id: string, name: string, stockQuantity: number}) => {
        if (!firestore || !shopOwnerId) return;

        const productRef = doc(firestore, `shops/${shopOwnerId}/products`, product.id);
        const newStockQuantity = product.stockQuantity > 0 ? 0 : 1; // Set to 0 if in stock, or 1 if out of stock
        
        updateDocumentNonBlocking(productRef, { stockQuantity: newStockQuantity });

        toast({
            title: "Stock Updated",
            description: `${product.name} is now ${newStockQuantity > 0 ? 'in stock' : 'out of stock'}.`,
        });
    };

    return (
        <div>
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-4">
                    <SellerBackButton />
                    <h1 className="text-2xl font-headline font-bold">My Products</h1>
                </div>
                <Button asChild>
                    <Link href="/seller/products/add">
                        <PlusCircle className="h-4 w-4 mr-2" />
                        Add Product
                    </Link>
                </Button>
            </div>
            <Card>
                <CardHeader>
                    <CardTitle>Product List</CardTitle>
                    <CardDescription>Manage your products and view their status.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="hidden w-[100px] sm:table-cell">Image</TableHead>
                                <TableHead>Name</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Price</TableHead>
                                <TableHead>Stock</TableHead>
                                <TableHead>Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {isLoading && (
                                <>
                                    <TableRow>
                                        <TableCell className="hidden sm:table-cell"><Skeleton className="h-16 w-16 rounded-md" /></TableCell>
                                        <TableCell><Skeleton className="h-6 w-32" /></TableCell>
                                        <TableCell><Skeleton className="h-6 w-16" /></TableCell>
                                        <TableCell><Skeleton className="h-6 w-12" /></TableCell>
                                        <TableCell><Skeleton className="h-6 w-10" /></TableCell>
                                        <TableCell><div className="flex gap-2"><Skeleton className="h-8 w-16" /><Skeleton className="h-8 w-16" /></div></TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell className="hidden sm:table-cell"><Skeleton className="h-16 w-16 rounded-md" /></TableCell>
                                        <TableCell><Skeleton className="h-6 w-32" /></TableCell>
                                        <TableCell><Skeleton className="h-6 w-16" /></TableCell>
                                        <TableCell><Skeleton className="h-6 w-12" /></TableCell>
                                        <TableCell><Skeleton className="h-6 w-10" /></TableCell>
                                        <TableCell><div className="flex gap-2"><Skeleton className="h-8 w-16" /><Skeleton className="h-8 w-16" /></div></TableCell>
                                    </TableRow>
                                </>
                            )}
                            {!isLoading && products?.map(product => {
                                const placeholder = getPlaceholderImage('product-1');
                                return (
                                    <TableRow key={product.id}>
                                        <TableCell className="hidden sm:table-cell">
                                            <Image 
                                                src={product.images?.[0] || placeholder.imageUrl} 
                                                alt={product.name} 
                                                width={64} 
                                                height={64} 
                                                className="rounded-md object-cover"
                                                data-ai-hint={placeholder.imageHint}
                                            />
                                        </TableCell>
                                        <TableCell className="font-medium">{product.name}</TableCell>
                                        <TableCell><Badge variant={product.stockQuantity > 0 ? 'default' : 'destructive'}>{product.stockQuantity > 0 ? 'In Stock' : 'Out of Stock'}</Badge></TableCell>
                                        <TableCell>${product.price.toFixed(2)}</TableCell>
                                        <TableCell>{product.stockQuantity}</TableCell>
                                        <TableCell className="flex gap-2">
                                            <Button variant="outline" size="sm">Edit</Button>
                                            <Button 
                                                variant={product.stockQuantity > 0 ? 'destructive' : 'secondary'}
                                                size="sm"
                                                onClick={() => handleStockToggle(product)}
                                            >
                                                {product.stockQuantity > 0 ? 'Out of Stock' : 'In Stock'}
                                            </Button>
                                        </TableCell>
                                    </TableRow>
                                )}
                            )}
                            {!isLoading && products?.length === 0 && (
                                <TableRow>
                                    <TableCell colSpan={6} className="text-center text-muted-foreground">
                                        You haven't added any products yet.
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    )
}
