'use client';

import { useState, useEffect } from 'react';
import { doc, getDocs, collection, query, where, arrayUnion } from 'firebase/firestore';
import { useFirestore, useUser, useDoc, useMemoFirebase, addDocumentNonBlocking, updateDocumentNonBlocking } from '@/firebase';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Image from 'next/image';
import { useToast } from '@/hooks/use-toast';
import { getPlaceholderImage } from '@/lib/placeholder-images';
import { SellerBackButton } from '@/components/shared/seller-back-button';
import { Label } from '@/components/ui/label';

type Product = {
    id: string;
    name: string;
    price: number;
    images?: string[];
};

// This is a placeholder. In a real app, you'd have a system to find available delivery personnel.
const AVAILABLE_DELIVERY_PERSON_ID = 'delivery-person-test-uid';

export default function SellerOrderDetailPage({ params }: { params: { orderId: string } }) {
  const firestore = useFirestore();
  const { user } = useUser();
  const { orderId } = params;
  const { toast } = useToast();

  const orderRef = useMemoFirebase(() => {
    if (!firestore || !orderId) return null;
    return doc(firestore, 'orders', orderId);
  }, [firestore, orderId]);

  const { data: order, isLoading: isOrderLoading, error } = useDoc(orderRef);
  
  const [products, setProducts] = useState<Product[]>([]);
  const [isProductsLoading, setIsProductsLoading] = useState(true);
  const [selectedStatus, setSelectedStatus] = useState<string>('');

  useEffect(() => {
    if (order?.status) {
      setSelectedStatus(order.status);
    }
  }, [order]);

  useEffect(() => {
    const fetchProducts = async () => {
      if (!firestore || !user?.uid || !order || !order.productIds || order.productIds.length === 0) {
        setIsProductsLoading(false);
        return;
      }
      
      try {
        // NOTE: Firestore 'in' queries are limited to 30 items.
        // For a single shop's products, this is usually fine.
        const productsRef = collection(firestore, `shops/${user.uid}/products`);
        const q = query(productsRef, where('__name__', 'in', order.productIds));
        const productSnap = await getDocs(q);
        const fetchedProducts = productSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product));
        setProducts(fetchedProducts);
      } catch (error) {
        console.error("Error fetching products:", error);
      } finally {
        setIsProductsLoading(false);
      }
    };

    if (order) {
        fetchProducts();
    }
  }, [firestore, order, user?.uid]);
  
  const createNotification = (userId: string, message: string, link: string) => {
      if (!firestore) return;
      const notificationsCollection = collection(firestore, 'notifications');
      addDocumentNonBlocking(notificationsCollection, {
          userId,
          message,
          link,
          read: false,
          createdAt: new Date().toISOString(),
      });
  };

  const handleStatusUpdate = () => {
    if (!orderRef || !selectedStatus || !order) return;
    
    const updateData: { status: string; deliveryPersonId?: string | null; members?: any } = {
      status: selectedStatus,
    };

    // If the seller marks the order as "Packed", assign a delivery person and generate OTP.
    if (selectedStatus === 'Packed' && !order.deliveryPersonId) {
      const deliveryPersonIdToAssign = AVAILABLE_DELIVERY_PERSON_ID;
      updateData.deliveryPersonId = deliveryPersonIdToAssign;
      updateData.deliveryOtp = Math.floor(100000 + Math.random() * 900000).toString(); // Generate 6-digit OTP
      updateData.members = arrayUnion(deliveryPersonIdToAssign);
      
      createNotification(
          deliveryPersonIdToAssign,
          `You have been assigned a new delivery: Order #${orderId.substring(0, 6)}.`,
          `/delivery/dashboard`
      );
       createNotification(
          order.customerId,
          `Your Order #${orderId.substring(0, 6)} is packed! An OTP has been generated.`,
          `/dashboard/orders/${orderId}`
      );
      toast({
          title: 'Delivery Person Assigned & OTP Generated',
          description: `Order assigned and OTP sent to customer.`,
      });
    }

    updateDocumentNonBlocking(orderRef, updateData);
    
    // Notify customer of other status changes
    if (selectedStatus !== 'Packed') {
      createNotification(
          order.customerId,
          `Your order #${orderId.substring(0, 6)} has been updated to: ${selectedStatus}.`,
          `/dashboard/orders/${orderId}`
      );
    }

    toast({
      title: 'Status Updated',
      description: `Order status changed to ${selectedStatus}.`,
    });
  };

  const isLoading = isOrderLoading || isProductsLoading;

  if (error) {
    return (
        <div>
            <div className="flex items-center gap-4 mb-4">
                <SellerBackButton />
                <h1 className="text-2xl font-headline font-bold text-destructive">Error</h1>
            </div>
            <Card>
                <CardHeader>
                    <CardTitle>Order Not Found</CardTitle>
                </CardHeader>
                <CardContent>
                    <p>There was an error loading this order, or you do not have permission to view it.</p>
                </CardContent>
            </Card>
        </div>
    )
  }

  return (
    <div>
      <div className="flex items-center gap-4 mb-4">
        <SellerBackButton />
        <h1 className="text-2xl font-headline font-bold">
          {isOrderLoading ? <Skeleton className="h-8 w-48" /> : `Order #${orderId.substring(0, 6)}...`}
        </h1>
      </div>
      
      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Products Ordered</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="hidden w-[80px] sm:table-cell">Image</TableHead>
                    <TableHead>Product</TableHead>
                    <TableHead className="text-right">Price</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading && Array.from({ length: 2 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell className="hidden sm:table-cell"><Skeleton className="h-16 w-16" /></TableCell>
                      <TableCell><Skeleton className="h-6 w-40" /></TableCell>
                      <TableCell className="text-right"><Skeleton className="h-6 w-16 ml-auto" /></TableCell>
                    </TableRow>
                  ))}
                  {!isLoading && products.map(product => {
                    const placeholder = getPlaceholderImage('product-1');
                    return (
                        <TableRow key={product.id}>
                        <TableCell className="hidden sm:table-cell">
                            <Image 
                                src={product.images?.[0] || placeholder.imageUrl} 
                                alt={product.name} 
                                width={64} height={64} 
                                className="rounded-md object-cover" 
                                data-ai-hint={placeholder.imageHint}
                            />
                        </TableCell>
                        <TableCell>{product.name}</TableCell>
                        <TableCell className="text-right">${product.price.toFixed(2)}</TableCell>
                        </TableRow>
                    )
                  })}
                  {!isLoading && products.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={3} className="text-center">No products found for this order.</TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Order Details</CardTitle>
              <CardDescription>
                {isOrderLoading ? <Skeleton className="h-4 w-40" /> : `Placed on ${order ? new Date(order.orderDate).toLocaleDateString() : 'N/A'}`}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {isOrderLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : order ? (
                <>
                  <div className="space-y-1">
                    <Label>Customer</Label>
                    <p className="text-sm text-muted-foreground">ID: {order.customerId.substring(0,8)}...</p>
                  </div>
                  <div className="space-y-1">
                    <Label>Shipping Address</Label>
                    <p className="text-sm text-muted-foreground">{order.shippingAddress}</p>
                  </div>
                  <div className="space-y-1">
                    <Label>Total</Label>
                    <p className="font-semibold">${order.totalAmount.toFixed(2)}</p>
                  </div>
                   <div className="space-y-1">
                    <Label>Delivery Person</Label>
                    <p className="text-sm text-muted-foreground">{order.deliveryPersonId ? `ID: ${order.deliveryPersonId.substring(0,8)}...` : 'Not Assigned'}</p>
                  </div>
                   {order.deliveryOtp && (
                     <div className="space-y-1">
                        <Label>Delivery OTP</Label>
                        <p className="text-sm font-semibold">{order.deliveryOtp}</p>
                    </div>
                  )}
                  <Separator />
                  <div className="space-y-2">
                    <Label>Update Status</Label>
                    <div className="flex gap-2">
                        <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                            <SelectTrigger>
                                <SelectValue placeholder="Change status" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="Placed">Placed</SelectItem>
                                <SelectItem value="Packed">Packed & Ready for Pickup</SelectItem>
                                <SelectItem value="Shipped">Shipped</SelectItem>
                                <SelectItem value="Delivered">Delivered</SelectItem>
                            </SelectContent>
                        </Select>
                        <Button onClick={handleStatusUpdate} disabled={selectedStatus === order.status}>Update</Button>
                    </div>
                  </div>
                </>
              ) : (
                <p>Order not found.</p>
              )}
            </CardContent>
            <CardFooter>
                {/* Actions like printing invoice can go here */}
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}
    