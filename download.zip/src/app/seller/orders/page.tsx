'use client';

import { useEffect, useRef } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useCollection, useFirestore, useMemoFirebase, useUser } from '@/firebase';
import { collection, query, where } from 'firebase/firestore';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import Link from 'next/link';
import { SellerBackButton } from '@/components/shared/seller-back-button';

export default function SellerOrdersPage() {
  const { toast } = useToast();
  const firestore = useFirestore();
  const { user } = useUser();
  const shopOwnerId = user?.uid; 

  const ordersQuery = useMemoFirebase(() => {
    if (!firestore || !shopOwnerId) return null;
    return query(
      collection(firestore, "orders"),
      where("members", "array-contains", shopOwnerId)
    );
  }, [firestore, shopOwnerId]);

  const { data: orders, isLoading } = useCollection(ordersQuery);
  const previousOrdersCount = useRef(0);

  useEffect(() => {
    if (isLoading || !user) {
      return;
    }

    if (orders) {
      if (orders.length > previousOrdersCount.current) {
        const newOrder = orders[orders.length - 1];
        if (previousOrdersCount.current > 0) { // Only toast for new orders after initial load
            toast({
              title: "New Order Received!",
              description: `Order #${newOrder.id.substring(0,6)} has been placed.`,
            });
        }
      }
      previousOrdersCount.current = orders.length;
    }
  }, [orders, toast, isLoading, user]);

  return (
    <div>
      <div className="flex items-center gap-4 mb-4">
        <SellerBackButton />
        <h1 className="text-2xl font-headline font-bold">Manage Orders</h1>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Incoming Orders</CardTitle>
          <CardDescription>
            { user ? 
              "A list of all orders will be displayed here. Click an order to see details." :
              "Please log in to see your orders."
            }
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order ID</TableHead>
                <TableHead>Customer ID</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading && (
                <>
                  <TableRow>
                    <TableCell colSpan={4}><Skeleton className="h-8" /></TableCell>
                  </TableRow>
                   <TableRow>
                    <TableCell colSpan={4}><Skeleton className="h-8" /></TableCell>
                  </TableRow>
                </>
              )}
              {!isLoading && orders?.map(order => (
                <TableRow key={order.id} className="cursor-pointer hover:bg-muted/50">
                  <TableCell className="font-medium">
                    <Link href={`/seller/orders/${order.id}`} className="block">#{order.id.substring(0, 6)}...</Link>
                  </TableCell>
                  <TableCell><Link href={`/seller/orders/${order.id}`} className="block">{order.customerId.substring(0, 6)}...</Link></TableCell>
                  <TableCell><Link href={`/seller/orders/${order.id}`} className="block">${order.totalAmount.toFixed(2)}</Link></TableCell>
                  <TableCell>
                    <Link href={`/seller/orders/${order.id}`} className="block">
                      <Badge variant={order.status === 'Delivered' ? 'default' : order.status === 'Pending' ? 'secondary' : 'outline'}>
                          {order.status}
                      </Badge>
                    </Link>
                  </TableCell>
                </TableRow>
              ))}
               {!isLoading && orders?.length === 0 && (
                <TableRow>
                  <TableCell colSpan={4} className="text-center text-muted-foreground">No orders found.</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
