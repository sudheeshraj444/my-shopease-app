
import { SellerBackButton } from "@/components/shared/seller-back-button";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export default function SellerAnalyticsPage() {
  return (
    <div>
      <div className="flex items-center gap-4 mb-4">
        <SellerBackButton />
        <h1 className="text-2xl font-headline font-bold">Analytics</h1>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Sales & Performance</CardTitle>
          <CardDescription>Detailed analytics and charts about your sales performance will be here.</CardDescription>
        </CardHeader>
        {/* Analytics charts will go here */}
      </Card>
    </div>
  );
}
