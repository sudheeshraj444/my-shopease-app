'use client';
import Link from "next/link";
import {
  Home,
  Package,
  PlusCircle,
  BarChart3,
  CircleDollarSign,
  Menu,
  Store,
  Settings,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { UserNav } from "@/components/layout/user-nav";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Logo } from "@/components/shared/logo";
import { ModeToggle } from "@/components/dark-mode-toggle";
import { useCollection, useDoc, useFirestore, useMemoFirebase, useUser, setDocumentNonBlocking } from "@/firebase";
import { collection, query, where, doc } from "firebase/firestore";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Notifications } from "@/components/layout/notifications";
import { useState, useEffect } from "react";

export default function SellerDashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const firestore = useFirestore();
  const { user } = useUser();
  const { toast } = useToast();
  const shopOwnerId = user?.uid;

  const ordersQuery = useMemoFirebase(() => {
    if (!firestore || !shopOwnerId) return null;
    return query(
      collection(firestore, "orders"),
      where("members", "array-contains", shopOwnerId)
    );
  }, [firestore, shopOwnerId]);

  const shopOwnerRef = useMemoFirebase(() => {
    if (!firestore || !shopOwnerId) return null;
    return doc(firestore, 'shopOwners', shopOwnerId);
  }, [firestore, shopOwnerId]);

  const { data: orders } = useCollection(ordersQuery);
  const { data: shopOwner, isLoading: isShopOwnerLoading } = useDoc(shopOwnerRef);

  const [isAccepting, setIsAccepting] = useState(false);
  const [initialStateSet, setInitialStateSet] = useState(false);

  useEffect(() => {
    // Only set the initial state from the database when shopOwner data first arrives
    // and the initial state has not yet been set.
    if (shopOwner && !isShopOwnerLoading && !initialStateSet) {
      setIsAccepting(shopOwner.isAcceptingOrders ?? false);
      setInitialStateSet(true);
    }
  }, [shopOwner, isShopOwnerLoading, initialStateSet]);
  
  const handleShopStatusToggle = (accepting: boolean) => {
    if (!shopOwnerRef) return;
    
    // 1. Update the local state immediately for instant UI feedback.
    setIsAccepting(accepting);
    
    // 2. Send the update to the database in the background.
    setDocumentNonBlocking(shopOwnerRef, { isAcceptingOrders: accepting }, { merge: true });

    toast({
        title: `Shop is now ${accepting ? 'open' : 'closed'}`,
        description: accepting ? 'You can now receive new orders.' : 'You will not receive new orders.',
    });
  }

  const navLinks = [
    { href: "/seller/dashboard", label: "Dashboard", icon: Home },
    { href: "/seller/orders", label: "Orders", icon: Package, badge: orders?.length.toString() },
    { href: "/seller/products", label: "Products", icon: PlusCircle },
    { href: "/seller/analytics", label: "Analytics", icon: BarChart3 },
    { href: "/seller/earnings", label: "Earnings", icon: CircleDollarSign },
    { href: "/seller/settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="grid min-h-screen w-full md:grid-cols-[220px_1fr] lg:grid-cols-[280px_1fr]">
      <div className="hidden border-r bg-muted/40 md:block">
        <div className="flex h-full max-h-screen flex-col gap-2">
          <div className="flex h-16 items-center border-b px-6">
            <Logo />
          </div>
          <div className="flex-1">
            <nav className="grid items-start px-4 text-sm font-medium">
              {navLinks.map(link => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <link.icon className="h-4 w-4" />
                  {link.label}
                  {link.badge && link.badge !== '0' && <Badge className="ml-auto flex h-6 w-6 shrink-0 items-center justify-center rounded-full">{link.badge}</Badge>}
                </Link>
              ))}
            </nav>
          </div>
          <div className="mt-auto p-4 border-t">
            <div className="flex items-center justify-between">
                <Label htmlFor="shop-status" className="flex items-center gap-2">
                    <Store className="h-4 w-4" />
                    Accepting Orders
                </Label>
                <Switch 
                    id="shop-status" 
                    checked={isAccepting}
                    onCheckedChange={handleShopStatusToggle}
                    disabled={isShopOwnerLoading}
                />
            </div>
          </div>
        </div>
      </div>
      <div className="flex flex-col">
        <header className="flex h-14 items-center gap-4 border-b bg-muted/40 px-4 lg:h-[60px] lg:px-6">
          <Sheet>
            <SheetTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="shrink-0 md:hidden"
              >
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle navigation menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="flex flex-col">
              <nav className="grid gap-2 text-lg font-medium">
                <div className="mb-4">
                  <Logo />
                </div>
                {navLinks.map(link => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="flex items-center gap-4 rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground"
                >
                  <link.icon className="h-5 w-5" />
                  {link.label}
                  {link.badge && link.badge !== '0' && <Badge className="ml-auto flex h-6 w-6 shrink-0 items-center justify-center rounded-full">{link.badge}</Badge>}
                </Link>
              ))}
              </nav>
               <div className="mt-auto p-4 border-t">
                <div className="flex items-center justify-between">
                    <Label htmlFor="shop-status-mobile" className="flex items-center gap-2">
                        <Store className="h-4 w-4" />
                        Accepting Orders
                    </Label>
                    <Switch 
                        id="shop-status-mobile" 
                        checked={isAccepting}
                        onCheckedChange={handleShopStatusToggle}
                        disabled={isShopOwnerLoading}
                    />
                </div>
              </div>
            </SheetContent>
          </Sheet>
          <div className="w-full flex-1">
             <h1 className="font-semibold text-lg">Seller Dashboard</h1>
          </div>
          <Notifications />
          <ModeToggle />
          <UserNav />
        </header>
        <main className="flex flex-1 flex-col gap-4 p-4 lg:gap-6 lg:p-6 bg-background">
            {children}
        </main>
      </div>
    </div>
  );
}
