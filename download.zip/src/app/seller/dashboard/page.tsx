'use client';

import { OverviewStats } from "@/components/seller/overview-stats";
import { SalesChart } from "@/components/seller/sales-chart";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useCollection, useFirestore, useUser, useMemoFirebase } from "@/firebase";
import { collection, query, where, limit } from "firebase/firestore";
import { Skeleton } from "@/components/ui/skeleton";
import Link from "next/link";
import { useMemo } from 'react';

export default function SellerDashboardPage() {
    const firestore = useFirestore();
    const { user } = useUser();
    const shopOwnerId = user?.uid;

    const recentOrdersQuery = useMemoFirebase(() => {
        if (!firestore || !shopOwnerId) return null;
        return query(
            collection(firestore, 'orders'),
            where('members', 'array-contains', shopOwnerId),
            // We can't orderBy date without a composite index, which can cause permission errors if not set up.
            // So we fetch a larger limit and sort/slice on the client.
            limit(20)
        );
    }, [firestore, shopOwnerId]);

    const { data: recentOrders, isLoading } = useCollection(recentOrdersQuery);

    const sortedRecentOrders = useMemo(() => {
        if (!recentOrders) return [];
        return [...recentOrders]
            .sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime())
            .slice(0, 5); // Take the top 5 most recent
    }, [recentOrders]);

  return (
    <div className="space-y-6">
        <h1 className="text-3xl font-headline font-bold">Dashboard</h1>
        <OverviewStats />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <SalesChart />
            <Card>
                <CardHeader>
                    <CardTitle>Recent Orders</CardTitle>
                    <CardDescription>A list of the most recent orders.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Customer</TableHead>
                                <TableHead>Amount</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Details</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {isLoading && (
                                Array.from({ length: 5 }).map((_, i) => (
                                <TableRow key={i}>
                                    <TableCell>
                                        <Skeleton className="h-4 w-24 mb-1" />
                                        <Skeleton className="h-3 w-32" />
                                    </TableCell>
                                    <TableCell><Skeleton className="h-4 w-12" /></TableCell>
                                    <TableCell><Skeleton className="h-6 w-16 rounded-full" /></TableCell>
                                    <TableCell><Skeleton className="h-8 w-20" /></TableCell>
                                </TableRow>
                                ))
                            )}
                            {!isLoading && sortedRecentOrders?.map(order => (
                                <TableRow key={order.id}>
                                    <TableCell>
                                        <div className="font-medium">Customer #{order.customerId.substring(0, 6)}</div>
                                        <div className="text-sm text-muted-foreground">{new Date(order.orderDate).toLocaleDateString()}</div>
                                    </TableCell>
                                    <TableCell>${order.totalAmount.toFixed(2)}</TableCell>
                                    <TableCell>
                                        <Badge variant={order.status === 'Shipped' || order.status === 'Delivered' ? 'default' : order.status === 'Pending' ? 'secondary' : 'destructive'}>{order.status}</Badge>
                                    </TableCell>
                                    <TableCell>
                                        <Link href={`/seller/orders/${order.id}`} className="text-sm font-medium text-primary hover:underline">View</Link>
                                    </TableCell>
                                </TableRow>
                            ))}
                            {!isLoading && sortedRecentOrders?.length === 0 && (
                                 <TableRow>
                                    <TableCell colSpan={4} className="text-center text-muted-foreground">No recent orders found.</TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    </div>
  );
}
    