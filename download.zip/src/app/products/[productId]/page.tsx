'use client';
import { doc, getDoc, collection, getDocs, query, limit, where } from 'firebase/firestore';
import { useFirestore, useDoc, useMemoFirebase } from '@/firebase';
import { useEffect, useState } from 'react';
import Image from 'next/image';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { Button } from '@/components/ui/button';
import { Star, Store } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { getPlaceholderImage } from '@/lib/placeholder-images';
import type { Product, ShopOwner } from '@/lib/types';
import { cn } from '@/lib/utils';
import { ProductCard } from '@/components/shared/product-card';
import { BackButton } from '@/components/shared/back-button';
import { useCartStore } from '@/lib/cart-store';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

export default function ProductDetailPage({ params }: { params: { productId: string } }) {
    const firestore = useFirestore();
    const [product, setProduct] = useState<Product | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
    const addItemToCart = useCartStore(state => state.addItem);
    const router = useRouter();

    const shopOwnerRef = useMemoFirebase(() => {
        if (!firestore || !product?.shopOwnerId) return null;
        return doc(firestore, 'shopOwners', product.shopOwnerId);
    }, [firestore, product?.shopOwnerId]);

    const { data: shopOwner } = useDoc<ShopOwner>(shopOwnerRef);

    useEffect(() => {
        const fetchProduct = async () => {
            if (!firestore || !params.productId) return;
            setIsLoading(true);
            try {
                const productRef = doc(firestore, `products/${params.productId}`);
                const productSnap = await getDoc(productRef);

                if (productSnap.exists()) {
                    const data = productSnap.data() as Omit<Product, 'id' | 'rating' | 'reviewCount' | 'image' | 'imageHint'>;
                    const displayProduct: Product = {
                        ...data,
                        id: productSnap.id,
                        rating: 4.5 + Math.random() * 0.5,
                        reviewCount: Math.floor(Math.random() * 1000) + 50,
                        image: data.images?.[0] || getPlaceholderImage('product-1').imageUrl,
                        imageHint: 'product',
                    };
                    setProduct(displayProduct);

                    const relatedQuery = query(
                        collection(firestore, `products`),
                        where('category', '==', data.category),
                        limit(5)
                    );
                    const relatedSnap = await getDocs(relatedQuery);
                    const fetchedRelated = relatedSnap.docs
                        .filter(doc => doc.id !== params.productId)
                        .map(doc => {
                             const pData = doc.data();
                             return {
                                id: doc.id,
                                name: pData.name,
                                description: pData.description,
                                price: pData.price,
                                stockQuantity: pData.stockQuantity,
                                images: pData.images,
                                category: pData.category,
                                shopOwnerId: pData.shopOwnerId,
                                rating: 4.5 + Math.random() * 0.5,
                                reviewCount: Math.floor(Math.random() * 1000) + 50,
                                image: pData.images?.[0] || getPlaceholderImage('product-1').imageUrl,
                                imageHint: 'product',
                             } as Product;
                        });
                    setRelatedProducts(fetchedRelated.slice(0,4));

                } else {
                    console.log("No such product!");
                }
            } catch (error) {
                console.error("Error fetching product:", error);
            } finally {
                setIsLoading(false);
            }
        };

        fetchProduct();
    }, [firestore, params.productId]);
    
    if (isLoading) {
        return <ProductDetailSkeleton />;
    }

    if (!product) {
        return (
             <div className="flex min-h-screen flex-col">
                <Header />
                <main className="flex-1 flex items-center justify-center bg-muted/40">
                    <div className="text-center">
                        <h1 className="text-2xl font-bold">Product not found</h1>
                        <p className="text-muted-foreground">The product you are looking for does not exist.</p>
                        <Button asChild className="mt-4">
                            <BackButton />
                        </Button>
                    </div>
                </main>
                <Footer />
            </div>
        )
    }

    const handleAddToCart = () => {
      if (product) {
        addItemToCart(product);
      }
    };
  
    const handleBuyNow = () => {
      if (product) {
        addItemToCart(product);
        router.push('/checkout');
      }
    };

    return (
        <div className="flex min-h-screen flex-col">
            <Header />
            <main className="flex-1 bg-muted/40">
                <div className="container mx-auto py-8">
                     <div className="mb-6">
                        <BackButton />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
                        <div>
                             <div className="aspect-square relative bg-background rounded-lg overflow-hidden border">
                                <Image src={product.image} alt={product.name} fill className="object-contain" data-ai-hint={product.imageHint}/>
                             </div>
                        </div>
                        <div>
                            <h1 className="text-3xl lg:text-4xl font-bold font-headline">{product.name}</h1>
                            <div className="flex items-center gap-4 mt-2">
                                <div className={cn(
                                    "flex items-center gap-1 text-sm font-semibold text-white px-2 py-0.5 rounded-full",
                                    product.rating >= 4 ? "bg-green-600" : product.rating >= 3 ? "bg-yellow-500" : "bg-red-500"
                                )}>
                                    <span>{product.rating.toFixed(1)}</span>
                                    <Star className="h-3 w-3 fill-white" />
                                </div>
                                <span className="text-sm text-muted-foreground">{product.reviewCount} Reviews</span>
                            </div>
                            <p className="text-3xl font-bold mt-4">${product.price.toFixed(2)}</p>
                            
                            <Separator className="my-6" />

                            <p className="text-muted-foreground leading-relaxed">{product.description}</p>
                            
                             <Separator className="my-6" />

                            {shopOwner && product.shopOwnerId && (
                                <Link href={`/shops/${product.shopOwnerId}`} className="flex items-center gap-4 p-4 border rounded-lg hover:bg-accent transition-colors">
                                    <Avatar className="h-12 w-12">
                                        <AvatarImage src={shopOwner.shopImageUrl || getPlaceholderImage('avatar').imageUrl} />
                                        <AvatarFallback><Store /></AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <p className="font-semibold">{shopOwner.shopName}</p>
                                        <p className="text-sm text-muted-foreground">View Store</p>
                                    </div>
                                </Link>
                            )}
                             

                             <Separator className="my-6" />

                            <div className="flex gap-4">
                                <Button size="lg" variant="outline" className="flex-1" onClick={handleAddToCart}>Add to Cart</Button>
                                <Button size="lg" className="flex-1" onClick={handleBuyNow}>Buy Now</Button>
                            </div>
                        </div>
                    </div>

                    <section className="py-12 mt-8">
                        <div className="flex items-center justify-between mb-4">
                            <h2 className="text-2xl font-headline font-bold">Related Products</h2>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                            {relatedProducts.map(p => <ProductCard key={p.id} product={p}/>)}
                        </div>
                    </section>
                </div>
            </main>
            <Footer />
        </div>
    )
}


function ProductDetailSkeleton() {
    return (
        <div className="flex min-h-screen flex-col">
            <Header />
            <main className="flex-1 bg-muted/40">
                 <div className="container mx-auto py-8">
                     <div className="mb-6">
                        <Skeleton className="h-10 w-24" />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
                         <div>
                            <Skeleton className="aspect-square w-full rounded-lg" />
                         </div>
                         <div className="space-y-4">
                            <Skeleton className="h-10 w-3/4" />
                            <Skeleton className="h-6 w-1/4" />
                            <Skeleton className="h-8 w-1/3 mt-4" />
                            <Separator className="my-6" />
                            <Skeleton className="h-20 w-full" />
                             <Separator className="my-6" />
                            <Skeleton className="h-16 w-full" />
                            <Separator className="my-6" />
                             <div className="flex gap-4">
                                 <Skeleton className="h-12 flex-1" />
                                 <Skeleton className="h-12 flex-1" />
                             </div>
                         </div>
                    </div>
                 </div>
            </main>
            <Footer />
        </div>
    )
}
