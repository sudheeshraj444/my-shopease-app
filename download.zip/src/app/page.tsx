'use client';
import Image from 'next/image';
import Link from 'next/link';
import { ChevronRight } from 'lucide-react';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@/components/ui/carousel';
import { Button } from '@/components/ui/button';
import { getPlaceholderImage } from '@/lib/placeholder-images';
import type { Category } from '@/lib/types';
import { ProductCard } from '@/components/shared/product-card';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { useCollection, useFirestore, useMemoFirebase } from '@/firebase';
import { collection, limit, query } from 'firebase/firestore';
import { Product } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardFooter } from '@/components/ui/card';

const mockCategories: Category[] = [
    { id: 'fashion', name: 'Fashion', image: getPlaceholderImage('category-fashion').imageUrl, imageHint: getPlaceholderImage('category-fashion').imageHint },
    { id: 'electronics', name: 'Electronics', image: getPlaceholderImage('category-electronics').imageUrl, imageHint: getPlaceholderImage('category-electronics').imageHint },
    { id: 'home', name: 'Home', image: getPlaceholderImage('category-home').imageUrl, imageHint: getPlaceholderImage('category-home').imageHint },
    { id: 'grocery', name: 'Grocery', image: getPlaceholderImage('category-grocery').imageUrl, imageHint: getPlaceholderImage('category-grocery').imageHint },
    { id: 'beauty', name: 'Beauty', image: getPlaceholderImage('category-beauty').imageUrl, imageHint: getPlaceholderImage('category-beauty').imageHint },
    { id: 'toys', name: 'Toys', image: getPlaceholderImage('category-toys').imageUrl, imageHint: getPlaceholderImage('category-toys').imageHint },
];

export default function HomePage() {
  const banner1 = getPlaceholderImage('banner-1');
  const banner2 = getPlaceholderImage('banner-2');
  const firestore = useFirestore();

  // Query the top-level 'products' collection for efficient, cross-shop browsing.
  const productsQuery = useMemoFirebase(() => {
    if (!firestore) return null;
    return query(collection(firestore, 'products'), limit(8));
  }, [firestore]);

  const { data: products, isLoading } = useCollection<Omit<Product, 'rating' | 'reviewCount'>>(productsQuery);

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <div className="container mx-auto">
          <section className="py-6">
            <Carousel
              opts={{
                align: 'start',
                loop: true,
              }}
              className="w-full"
            >
              <CarouselContent>
                <CarouselItem>
                  <div className="relative h-56 md:h-[400px] w-full rounded-lg overflow-hidden">
                    <Image src={banner1.imageUrl} alt={banner1.description} fill style={{ objectFit: 'cover' }} data-ai-hint={banner1.imageHint} />
                  </div>
                </CarouselItem>
                <CarouselItem>
                  <div className="relative h-56 md:h-[400px] w-full rounded-lg overflow-hidden">
                    <Image src={banner2.imageUrl} alt={banner2.description} fill style={{ objectFit: 'cover' }} data-ai-hint={banner2.imageHint} />
                  </div>
                </CarouselItem>
              </CarouselContent>
              <CarouselPrevious className="left-4" />
              <CarouselNext className="right-4" />
            </Carousel>
          </section>

          <section className="py-6">
            <h2 className="text-2xl font-headline font-bold mb-4">Shop by Category</h2>
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4">
              {mockCategories.map((category) => (
                <Link href={`/categories/${category.id}`} key={category.id} className="group flex flex-col items-center gap-2 text-center">
                  <div className="w-24 h-24 relative rounded-full overflow-hidden border-2 border-transparent group-hover:border-primary transition-colors">
                    <Image src={category.image} alt={category.name} fill className="object-cover" data-ai-hint={category.imageHint} />
                  </div>
                  <span className="font-semibold text-sm">{category.name}</span>
                </Link>
              ))}
            </div>
          </section>

          <section className="py-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-headline font-bold">Popular Products</h2>
              <Button variant="ghost" asChild>
                <Link href="/products">
                  View All <ChevronRight className="h-4 w-4 ml-1" />
                </Link>
              </Button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {isLoading && Array.from({ length: 8 }).map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-0">
                    <Skeleton className="w-full h-48" />
                  </CardContent>
                  <CardFooter className="flex-col items-start p-4">
                     <Skeleton className="h-6 w-3/4 mb-2" />
                     <Skeleton className="h-4 w-1/2" />
                  </CardFooter>
                </Card>
              ))}
              {!isLoading && products?.map((product) => {
                  const displayProduct: Product = {
                    ...product,
                    // Mock data for fields not in firestore
                    rating: 4.5 + Math.random() * 0.5,
                    reviewCount: Math.floor(Math.random() * 1000) + 50,
                    image: product.images?.[0] || getPlaceholderImage('product-1').imageUrl,
                    imageHint: 'product',
                  }
                  return <ProductCard key={product.id} product={displayProduct} />
              })}
            </div>
             {!isLoading && products?.length === 0 && (
                <div className="text-center col-span-full text-muted-foreground py-12">
                    No products found. Add some from the seller dashboard to see them here.
                </div>
            )}
          </section>
        </div>
      </main>
      <Footer />
    </div>
  );
}
