'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import Link from "next/link";
import { ArrowLeft, CreditCard, Landmark, Wallet, MapPin, HandCoins } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useUser, useFirestore, addDocumentNonBlocking } from '@/firebase';
import { collection } from 'firebase/firestore';
import { useCartStore } from '@/lib/cart-store';

const checkoutSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  address: z.string().min(5, "Address is required"),
  city: z.string().min(1, "City is required"),
  state: z.string().min(1, "State is required"),
  zip: z.string().min(1, "Zip code is required"),
  paymentMethod: z.enum(["card", "upi", "wallet", "cod"], {
    required_error: "You need to select a payment method.",
  }),
});

type CheckoutFormData = z.infer<typeof checkoutSchema>;


export default function CheckoutPage() {
    const { toast } = useToast();
    const router = useRouter();
    const { user, isUserLoading } = useUser();
    const firestore = useFirestore();
    const [isClient, setIsClient] = useState(false);
    const { items: cartItems, clearCart, setRedirectUrl } = useCartStore();

    const cartValue = cartItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    const shippingCost = cartValue > 0 ? 5.00 : 0;
    const tax = cartValue > 0 ? cartValue * 0.08 : 0; // 8% tax
    const total = cartValue + shippingCost + tax;


    useEffect(() => {
        setIsClient(true);
    }, []);

    useEffect(() => {
      // If the user is not logged in and not loading, redirect them.
      if (!isUserLoading && !user) {
        toast({
          title: "Please Log In",
          description: "You need to log in to proceed to checkout.",
        });
        setRedirectUrl('/checkout'); // Save the intended destination
        router.push('/login');
      }
    }, [user, isUserLoading, router, toast, setRedirectUrl]);
    
    const { register, handleSubmit, setValue, watch, formState: { errors } } = useForm<CheckoutFormData>({
      resolver: zodResolver(checkoutSchema),
      defaultValues: {
          address: '',
          paymentMethod: 'card'
      }
    });

    const handleLocationClick = () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const { latitude, longitude } = position.coords;
                    const locationString = `Lat: ${latitude.toFixed(4)}, Lng: ${longitude.toFixed(4)}`;
                    setValue('address', locationString, { shouldValidate: true });
                    toast({
                        title: "Location Fetched",
                        description: "Your current location has been set as the address.",
                    });
                },
                (error) => {
                    console.error("Geolocation error:", error);
                    toast({
                        variant: "destructive",
                        title: "Location Error",
                        description: "Could not retrieve your location. Please enter it manually.",
                    });
                }
            );
        } else {
            toast({
                variant: "destructive",
                title: "Unsupported",
                description: "Your browser does not support geolocation.",
            });
        }
    };
    
    const onSubmit = (data: CheckoutFormData) => {
        if (!user || !firestore) {
             toast({
                variant: "destructive",
                title: "Error",
                description: "You must be logged in to place an order.",
            });
            return;
        }

        if (cartItems.length === 0) {
            toast({
                variant: "destructive",
                title: "Empty Cart",
                description: "You cannot place an order with an empty cart.",
            });
            return;
        }

        const ordersCollection = collection(firestore, 'orders');
        // This assumes a single-vendor cart. For multi-vendor, you'd group items by shopOwnerId
        // and create separate orders.
        const shopOwnerIds = [...new Set(cartItems.map(item => item.product.shopOwnerId))];
        
        shopOwnerIds.forEach(shopOwnerId => {
            const itemsForShop = cartItems.filter(item => item.product.shopOwnerId === shopOwnerId);
            const shopTotal = itemsForShop.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

            const newOrder = {
                customerId: user.uid,
                shopOwnerId: shopOwnerId, 
                deliveryPersonId: null,
                orderDate: new Date().toISOString(),
                totalAmount: shopTotal, // In a real app, shipping/tax would be pro-rated or calculated per-shop
                shippingAddress: `${data.address}, ${data.city}, ${data.state} ${data.zip}`,
                status: "Placed",
                paymentMethod: data.paymentMethod,
                productIds: itemsForShop.map(item => item.product.id),
                deliveryOtp: null,
                members: [user.uid, shopOwnerId], // Add members array for security rules
            };
            addDocumentNonBlocking(ordersCollection, newOrder);
        });
        
        clearCart();
        setRedirectUrl(null); // Clear the redirect URL after successful order

        toast({
            title: "Order Placed!",
            description: "Thank you for your purchase. You will be redirected to your orders.",
        });

        router.push('/orders');
    }

    if (!isClient || isUserLoading || !user) {
        return (
             <div className="flex min-h-screen flex-col items-center justify-center">
                <p>Loading checkout...</p>
            </div>
        );
    }

    return (
        <div className="flex min-h-screen flex-col">
            <Header />
            <main className="flex-1 bg-muted/40">
                <div className="container mx-auto py-8">
                    <div className="flex justify-between items-center mb-6">
                         <Button variant="outline" asChild>
                            <Link href="/cart">
                                <ArrowLeft className="mr-2 h-4 w-4" />
                                Back to Cart
                            </Link>
                        </Button>
                        <h1 className="text-3xl font-bold font-headline">Checkout</h1>
                    </div>
                    {cartItems.length === 0 ? (
                         <Card>
                            <CardContent className="p-12 text-center text-muted-foreground">
                                <p>Your cart is empty. You cannot proceed to checkout.</p>
                                <Button asChild className="mt-4">
                                    <Link href="/">Continue Shopping</Link>
                                </Button>
                            </CardContent>
                        </Card>
                    ) : (
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                            <div className="lg:col-span-2">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Shipping & Payment</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="space-y-4">
                                            <div className="flex justify-between items-center">
                                                <h3 className="text-lg font-semibold">Shipping Address</h3>
                                                <Button type="button" variant="outline" size="sm" onClick={handleLocationClick}>
                                                    <MapPin className="mr-2 h-4 w-4"/>
                                                    Use My Location
                                                </Button>
                                            </div>
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                <div className="space-y-2">
                                                    <Label htmlFor="firstName">First Name</Label>
                                                    <Input id="firstName" placeholder="John" {...register('firstName')} />
                                                    {errors.firstName && <p className="text-sm text-destructive">{errors.firstName.message}</p>}
                                                </div>
                                                <div className="space-y-2">
                                                    <Label htmlFor="lastName">Last Name</Label>
                                                    <Input id="lastName" placeholder="Doe" {...register('lastName')} />
                                                    {errors.lastName && <p className="text-sm text-destructive">{errors.lastName.message}</p>}
                                                </div>
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="address">Address</Label>
                                                <Input 
                                                    id="address" 
                                                    placeholder="123 Main St or Lat/Lng" 
                                                    {...register('address')}
                                                />
                                                 {errors.address && <p className="text-sm text-destructive">{errors.address.message}</p>}
                                            </div>
                                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                                <div className="space-y-2">
                                                    <Label htmlFor="city">City</Label>
                                                    <Input id="city" placeholder="Anytown" {...register('city')} />
                                                    {errors.city && <p className="text-sm text-destructive">{errors.city.message}</p>}
                                                </div>
                                                <div className="space-y-2">
                                                    <Label htmlFor="state">State</Label>
                                                    <Input id="state" placeholder="CA" {...register('state')} />
                                                    {errors.state && <p className="text-sm text-destructive">{errors.state.message}</p>}
                                                </div>
                                                <div className="space-y-2">
                                                    <Label htmlFor="zip">Zip Code</Label>
                                                    <Input id="zip" placeholder="12345" {...register('zip')} />
                                                    {errors.zip && <p className="text-sm text-destructive">{errors.zip.message}</p>}
                                                </div>
                                            </div>
                                        </div>
                                        <Separator />
                                        <div className="space-y-4">
                                            <h3 className="text-lg font-semibold">Payment Method</h3>
                                            <RadioGroup 
                                                defaultValue="card" 
                                                className="space-y-2"
                                                onValueChange={(value) => setValue('paymentMethod', value as "card" | "upi" | "wallet" | "cod")}
                                            >
                                                <div className="flex items-center space-x-2 border rounded-md p-4 has-[:checked]:border-primary">
                                                    <RadioGroupItem value="card" id="card" />
                                                    <Label htmlFor="card" className="flex items-center gap-4 cursor-pointer">
                                                        <CreditCard className="h-5 w-5" />
                                                        <span>Pay with Card</span>
                                                    </Label>
                                                </div>
                                                <div className="flex items-center space-x-2 border rounded-md p-4 has-[:checked]:border-primary">
                                                    <RadioGroupItem value="upi" id="upi" />
                                                    <Label htmlFor="upi" className="flex items-center gap-4 cursor-pointer">
                                                        <Landmark className="h-5 w-5" />
                                                        <span>Pay with UPI (GPay, PhonePe) / Netbanking</span>
                                                    </Label>
                                                </div>
                                                <div className="flex items-center space-x-2 border rounded-md p-4 has-[:checked]:border-primary">
                                                    <RadioGroupItem value="wallet" id="wallet" />
                                                    <Label htmlFor="wallet" className="flex items-center gap-4 cursor-pointer">
                                                        <Wallet className="h-5 w-5" />
                                                        <span>Pay with Wallet Balance</span>
                                                    </Label>
                                                </div>
                                                <div className="flex items-center space-x-2 border rounded-md p-4 has-[:checked]:border-primary">
                                                    <RadioGroupItem value="cod" id="cod" />
                                                    <Label htmlFor="cod" className="flex items-center gap-4 cursor-pointer">
                                                        <HandCoins className="h-5 w-5" />
                                                        <span>Cash on Delivery</span>
                                                    </Label>
                                                </div>
                                            </RadioGroup>
                                            {errors.paymentMethod && <p className="text-sm text-destructive">{errors.paymentMethod.message}</p>}
                                        </div>
                                    </CardContent>
                                </Card>
                            </div>
                            <div>
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Order Summary</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        {cartItems.map(item => (
                                            <div key={item.product.id} className="flex justify-between items-center text-sm">
                                                <span>{item.product.name} x {item.quantity}</span>
                                                <span>${(item.product.price * item.quantity).toFixed(2)}</span>
                                            </div>
                                        ))}
                                        <Separator />
                                        <div className="flex justify-between text-sm">
                                            <span>Subtotal</span>
                                            <span>${cartValue.toFixed(2)}</span>
                                        </div>
                                        <div className="flex justify-between text-sm">
                                            <span>Shipping</span>
                                            <span>${shippingCost.toFixed(2)}</span>
                                        </div>
                                        <div className="flex justify-between text-sm">
                                            <span>Tax</span>
                                            <span>${tax.toFixed(2)}</span>
                                        </div>
                                        <Separator />
                                        <div className="flex justify-between font-bold text-lg">
                                            <span>Total</span>
                                            <span>${total.toFixed(2)}</span>
                                        </div>
                                    </CardContent>
                                    <CardFooter>
                                        <Button type="submit" className="w-full" disabled={isUserLoading}>Place Order</Button>
                                    </CardFooter>
                                </Card>
                            </div>
                        </div>
                    </form>
                    )}
                </div>
            </main>
            <Footer />
        </div>
    )
}
    