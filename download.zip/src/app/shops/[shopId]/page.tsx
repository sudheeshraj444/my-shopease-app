'use client';
import { useDoc, useCollection, useFirestore, useMemoFirebase } from '@/firebase';
import { doc, collection, query, where } from 'firebase/firestore';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import Image from 'next/image';
import { Skeleton } from '@/components/ui/skeleton';
import { getPlaceholderImage } from '@/lib/placeholder-images';
import type { ShopOwner, Product } from '@/lib/types';
import { ProductCard } from '@/components/shared/product-card';
import { MapPin, Store } from 'lucide-react';
import { BackButton } from '@/components/shared/back-button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';

export default function ShopPage({ params }: { params: { shopId: string } }) {
    const firestore = useFirestore();
    const { shopId } = params;

    const shopOwnerRef = useMemoFirebase(() => {
        if (!firestore || !shopId) return null;
        return doc(firestore, 'shopOwners', shopId);
    }, [firestore, shopId]);

    const productsQuery = useMemoFirebase(() => {
        if (!firestore || !shopId) return null;
        return query(collection(firestore, 'products'), where('shopOwnerId', '==', shopId));
    }, [firestore, shopId]);

    const { data: shopOwner, isLoading: isShopLoading } = useDoc<ShopOwner>(shopOwnerRef);
    const { data: products, isLoading: areProductsLoading } = useCollection<Omit<Product, 'rating' | 'reviewCount'>>(productsQuery);
    
    const isLoading = isShopLoading || areProductsLoading;

    if (isLoading) {
        return <ShopPageSkeleton />;
    }

    if (!shopOwner) {
        return (
            <div className="flex min-h-screen flex-col">
                <Header />
                <main className="flex-1 flex items-center justify-center bg-muted/40">
                    <div className="text-center">
                        <Store className="mx-auto h-12 w-12 text-muted-foreground" />
                        <h1 className="mt-4 text-2xl font-bold">Shop not found</h1>
                        <p className="text-muted-foreground">The shop you are looking for does not exist.</p>
                        <Button asChild className="mt-4">
                            <BackButton />
                        </Button>
                    </div>
                </main>
                <Footer />
            </div>
        );
    }
    
    const bannerImage = getPlaceholderImage('banner-1');

    return (
        <div className="flex min-h-screen flex-col">
            <Header />
            <main className="flex-1 bg-muted/40">
                <div className="h-48 md:h-64 w-full relative">
                    <Image src={bannerImage.imageUrl} alt={shopOwner.shopName} fill className="object-cover" data-ai-hint={bannerImage.imageHint}/>
                    <div className="absolute inset-0 bg-black/50" />
                </div>

                <div className="container mx-auto -mt-20">
                     <div className="bg-card p-6 rounded-lg shadow-lg flex flex-col md:flex-row items-center gap-6">
                        <div className="relative h-32 w-32 rounded-full border-4 border-background -mt-16 md:-mt-0">
                           <Image 
                                src={shopOwner.shopImageUrl || getPlaceholderImage('category-home').imageUrl} 
                                alt={shopOwner.shopName} 
                                fill
                                className="object-cover rounded-full"
                                data-ai-hint="storefront"
                           />
                        </div>
                        <div className="text-center md:text-left">
                            <h1 className="text-3xl font-bold font-headline">{shopOwner.shopName}</h1>
                            {shopOwner.address && (
                                <p className="text-muted-foreground flex items-center justify-center md:justify-start gap-2 mt-1">
                                    <MapPin className="h-4 w-4" /> {shopOwner.address}
                                </p>
                            )}
                        </div>
                    </div>

                    <div className="py-8">
                         <h2 className="text-2xl font-bold font-headline mb-4">All Products from {shopOwner.shopName}</h2>
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                            {areProductsLoading && Array.from({ length: 4 }).map((_, i) => (
                                <Card key={i}>
                                    <CardContent className="p-0"><Skeleton className="w-full h-48" /></CardContent>
                                    <CardFooter className="flex-col items-start p-4"><Skeleton className="h-6 w-3/4 mb-2" /><Skeleton className="h-4 w-1/2" /></CardFooter>
                                </Card>
                            ))}
                            
                            {!areProductsLoading && products?.map((product) => {
                                const displayProduct: Product = {
                                    ...product,
                                    rating: 4.5 + Math.random() * 0.5,
                                    reviewCount: Math.floor(Math.random() * 1000) + 50,
                                    image: product.images?.[0] || getPlaceholderImage('product-1').imageUrl,
                                    imageHint: 'product',
                                }
                                return <ProductCard key={product.id} product={displayProduct} />
                            })}
                        </div>
                        {!areProductsLoading && (!products || products.length === 0) && (
                            <div className="col-span-full text-center text-muted-foreground py-12 border-2 border-dashed rounded-lg">
                                <p>This shop hasn't added any products yet.</p>
                            </div>
                        )}
                    </div>
                </div>

            </main>
            <Footer />
        </div>
    );
}


function ShopPageSkeleton() {
    return (
        <div className="flex min-h-screen flex-col">
            <Header />
            <main className="flex-1 bg-muted/40">
                <Skeleton className="h-48 md:h-64 w-full" />
                 <div className="container mx-auto -mt-20">
                    <div className="bg-card p-6 rounded-lg shadow-lg flex items-center gap-6">
                        <Skeleton className="relative h-32 w-32 rounded-full border-4 border-background" />
                        <div>
                            <Skeleton className="h-9 w-48 mb-2" />
                            <Skeleton className="h-5 w-64" />
                        </div>
                    </div>
                     <div className="py-8">
                         <Skeleton className="h-8 w-72 mb-4" />
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                            {Array.from({ length: 4 }).map((_, i) => (
                                <Card key={i}>
                                    <CardContent className="p-0"><Skeleton className="w-full h-48" /></CardContent>
                                    <CardFooter className="flex-col items-start p-4"><Skeleton className="h-6 w-3/4 mb-2" /><Skeleton className="h-4 w-1/2" /></CardFooter>
                                </Card>
                            ))}
                        </div>
                    </div>
                </div>
            </main>
            <Footer />
        </div>
    );
}
