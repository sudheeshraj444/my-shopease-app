'use client';

import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { Input } from '@/components/ui/input';
import { Search as SearchIcon, Loader2, Package, Store } from 'lucide-react';
import { useCollection, useFirestore, useMemoFirebase } from '@/firebase';
import { collection, query, limit, where } from 'firebase/firestore';
import type { ShopOwner, Product } from '@/lib/types';
import { ProductCard } from '@/components/shared/product-card';
import Link from 'next/link';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { getPlaceholderImage } from '@/lib/placeholder-images';
import { Card, CardContent } from '@/components/ui/card';

export default function SearchPage() {
    const searchParams = useSearchParams();
    const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
    const [debouncedQuery, setDebouncedQuery] = useState(searchQuery);

    const firestore = useFirestore();

    // Debounce search query
    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedQuery(searchQuery);
        }, 300);

        return () => {
            clearTimeout(handler);
        };
    }, [searchQuery]);

    const shopsQuery = useMemoFirebase(() => {
        if (!firestore || !debouncedQuery) return null;
        const q = debouncedQuery.charAt(0).toUpperCase() + debouncedQuery.slice(1);
        return query(
            collection(firestore, 'shopOwners'),
            where('shopName', '>=', q),
            where('shopName', '<=', q + '\uf8ff'),
            limit(10)
        );
    }, [firestore, debouncedQuery]);
    const { data: foundShops, isLoading: areShopsLoading } = useCollection<ShopOwner>(shopsQuery);

    const productsQuery = useMemoFirebase(() => {
        if (!firestore || !debouncedQuery) return null;
        const q = debouncedQuery.charAt(0).toUpperCase() + debouncedQuery.slice(1);
        return query(
            collection(firestore, 'products'),
            where('name', '>=', q),
            where('name', '<=', q + '\uf8ff'),
            limit(20)
        );
    }, [firestore, debouncedQuery]);
    const { data: foundProducts, isLoading: areProductsLoading } = useCollection<Omit<Product, 'rating' | 'reviewCount' | 'image' | 'imageHint'>>(productsQuery);
    
    const isLoading = areShopsLoading || areProductsLoading;

    return (
        <div className="flex min-h-screen flex-col">
            <Header />
            <main className="flex-1 bg-muted/40">
                <div className="container mx-auto py-8">
                    <div className="relative mb-8">
                        <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                        <Input
                            type="search"
                            placeholder="Search products or shops..."
                            className="w-full rounded-lg bg-background pl-10 h-12 text-lg"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            autoFocus
                        />
                    </div>
                    
                    {isLoading && debouncedQuery ? (
                        <div className="flex items-center justify-center p-12">
                            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                        </div>
                    ) : (
                        <>
                            {debouncedQuery && (!foundShops || foundShops.length === 0) && (!foundProducts || foundProducts.length === 0) && (
                                <div className="text-center text-muted-foreground py-16">
                                    <h2 className="text-xl font-semibold">No results found for &quot;{debouncedQuery}&quot;</h2>
                                    <p>Try searching for something else.</p>
                                </div>
                            )}

                            {!debouncedQuery && (
                                <div className="text-center text-muted-foreground py-16">
                                    <h2 className="text-xl font-semibold">Search for anything</h2>
                                    <p>Find your favorite products and shops in one place.</p>
                                </div>
                            )}

                            <div className="space-y-8">
                                {foundShops && foundShops.length > 0 && (
                                    <section>
                                        <h2 className="text-2xl font-bold font-headline mb-4">Shops</h2>
                                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                                            {foundShops.map(shop => {
                                                const avatar = getPlaceholderImage('avatar');
                                                return (
                                                    <Link key={shop.id} href={`/shops/${shop.id}`}>
                                                        <Card className="hover:shadow-md transition-shadow">
                                                            <CardContent className="flex items-center gap-4 p-4">
                                                                <Avatar className="h-16 w-16">
                                                                    <AvatarImage src={shop.shopImageUrl || avatar.imageUrl} alt={shop.shopName} />
                                                                    <AvatarFallback><Store /></AvatarFallback>
                                                                </Avatar>
                                                                <div>
                                                                    <p className="font-semibold text-lg">{shop.shopName}</p>
                                                                    <p className="text-sm text-muted-foreground truncate">{shop.address || 'Address not available'}</p>
                                                                </div>
                                                            </CardContent>
                                                        </Card>
                                                    </Link>
                                                )
                                            })}
                                        </div>
                                    </section>
                                )}

                                {foundProducts && foundProducts.length > 0 && (
                                    <section>
                                         <h2 className="text-2xl font-bold font-headline mb-4">Products</h2>
                                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                                            {foundProducts.map((product) => {
                                                const displayProduct: Product = {
                                                    ...product,
                                                    rating: 4.5 + Math.random() * 0.5,
                                                    reviewCount: Math.floor(Math.random() * 1000) + 50,
                                                    image: product.images?.[0] || getPlaceholderImage('product-1').imageUrl,
                                                    imageHint: 'product',
                                                };
                                                return <ProductCard key={product.id} product={displayProduct} />
                                            })}
                                        </div>
                                    </section>
                                )}
                            </div>
                        </>
                    )}
                </div>
            </main>
            <Footer />
        </div>
    );
}
