'use client';

import { useUser, useDoc, useFirestore, useMemoFirebase, useCollection } from '@/firebase';
import { doc, collection, query, where, limit } from 'firebase/firestore';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Wallet, Landmark, Package, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { Skeleton } from '@/components/ui/skeleton';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from '@/components/ui/badge';
import { useMemo } from 'react';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';

export default function CustomerDashboardPage() {
    const firestore = useFirestore();
    const { user } = useUser();
    const customerId = user?.uid;

    const customerRef = useMemoFirebase(() => {
        if (!firestore || !customerId) return null;
        return doc(firestore, 'customers', customerId);
    }, [firestore, customerId]);
    
    const { data: customer, isLoading: isCustomerLoading } = useDoc(customerRef);

    const ordersQuery = useMemoFirebase(() => {
        if (!firestore || !customerId) return null;
        return query(
            collection(firestore, 'orders'),
            where('members', 'array-contains', customerId),
            limit(5)
        );
    }, [firestore, customerId]);
    
    const { data: orders, isLoading: areOrdersLoading } = useCollection(ordersQuery);
    
    const sortedOrders = useMemo(() => {
        if (!orders) return [];
        return [...orders].sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime());
    }, [orders]);

    const isLoading = isCustomerLoading || areOrdersLoading;

    return (
        <div className="flex min-h-screen flex-col">
            <Header />
            <main className="flex-1 bg-muted/40">
                <div className="container mx-auto py-8">
                     <div className="space-y-6">
                        <div>
                            <h1 className="text-3xl font-headline font-bold">Welcome, {customer?.name?.split(' ')[0] || 'Customer'}!</h1>
                            <p className="text-muted-foreground">Here's a quick overview of your account.</p>
                        </div>

                        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                            <Card>
                                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                    <CardTitle className="text-sm font-medium">Wallet Balance</CardTitle>
                                    <Wallet className="h-4 w-4 text-muted-foreground" />
                                </CardHeader>
                                <CardContent>
                                    {isLoading ? <Skeleton className="h-8 w-24" /> : <div className="text-2xl font-bold">${(customer?.walletBalance ?? 0).toFixed(2)}</div>}
                                    <Button variant="link" asChild className="p-0 h-auto text-xs text-muted-foreground">
                                        <Link href="/dashboard/wallet">Manage Wallet</Link>
                                    </Button>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                    <CardTitle className="text-sm font-medium">Loyalty Points</CardTitle>
                                    <Landmark className="h-4 w-4 text-muted-foreground" />
                                </CardHeader>
                                <CardContent>
                                    {isLoading ? <Skeleton className="h-8 w-16" /> : <div className="text-2xl font-bold">{customer?.loyaltyPoints ?? 0}</div>}
                                    <p className="text-xs text-muted-foreground">Keep shopping to earn more!</p>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                    <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
                                    <Package className="h-4 w-4 text-muted-foreground" />
                                </CardHeader>
                                <CardContent>
                                    {isLoading ? <Skeleton className="h-8 w-16" /> : <div className="text-2xl font-bold">{orders?.length ?? 0}</div>}
                                    <Button variant="link" asChild className="p-0 h-auto text-xs text-muted-foreground">
                                        <Link href="/orders">View All Orders</Link>
                                    </Button>
                                </CardContent>
                            </Card>
                        </div>

                        <Card>
                            <CardHeader>
                                <div className="flex items-center justify-between">
                                    <div>
                                        <CardTitle>Recent Orders</CardTitle>
                                        <CardDescription>Your 5 most recent orders.</CardDescription>
                                    </div>
                                    <Button asChild variant="outline">
                                        <Link href="/orders">View All <ArrowRight className="ml-2 h-4 w-4" /></Link>
                                    </Button>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Order ID</TableHead>
                                            <TableHead>Date</TableHead>
                                            <TableHead>Total</TableHead>
                                            <TableHead>Status</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {isLoading && Array.from({ length: 3 }).map((_, i) => (
                                            <TableRow key={i}>
                                                <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                                                <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                                                <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                                                <TableCell><Skeleton className="h-6 w-20 rounded-full" /></TableCell>
                                            </TableRow>
                                        ))}
                                        {!isLoading && sortedOrders.length > 0 && sortedOrders.map(order => (
                                            <TableRow key={order.id} className="cursor-pointer">
                                                <TableCell className="font-medium">
                                                    <Link href={`/orders/${order.id}`}>#{order.id.substring(0, 6)}...</Link>
                                                </TableCell>
                                                <TableCell>{new Date(order.orderDate).toLocaleDateString()}</TableCell>
                                                <TableCell>${order.totalAmount.toFixed(2)}</TableCell>
                                                <TableCell><Badge variant={order.status === 'Delivered' ? 'default' : 'secondary'}>{order.status}</Badge></TableCell>
                                            </TableRow>
                                        ))}
                                        {!isLoading && sortedOrders.length === 0 && (
                                            <TableRow>
                                                <TableCell colSpan={4} className="h-24 text-center">
                                                    You have no recent orders.
                                                </TableCell>
                                            </TableRow>
                                        )}
                                    </TableBody>
                                </Table>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </main>
            <Footer />
        </div>
    );
}
