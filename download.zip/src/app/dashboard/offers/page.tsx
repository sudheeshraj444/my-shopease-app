'use client';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { useCollection, useFirestore, useMemoFirebase, useUser } from "@/firebase";
import { collection } from "firebase/firestore";
import { Skeleton } from "@/components/ui/skeleton";
import { Tag } from "lucide-react";
import { BackButton } from "@/components/shared/back-button";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";

export default function CustomerOffersPage() {
    const firestore = useFirestore();
    const { user, isUserLoading } = useUser();
    
    const couponsQuery = useMemoFirebase(() => {
        // Wait until auth state is determined and user is logged in
        if (isUserLoading || !user || !firestore) return null;
        return collection(firestore, 'coupons');
    }, [firestore, user, isUserLoading]);

    const {data: coupons, isLoading} = useCollection(couponsQuery);
    
    const finalIsLoading = isLoading || isUserLoading;

  return (
    <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1 bg-muted/40">
            <div className="container mx-auto py-8">
                <div className="flex items-center gap-4 mb-4">
                    <BackButton />
                    <h1 className="text-2xl font-headline font-bold">Offers & Coupons</h1>
                </div>
            <Card>
                <CardHeader>
                <CardTitle>Available Offers</CardTitle>
                <CardDescription>All available offers and coupons will be listed here.</CardDescription>
                </CardHeader>
                <CardContent>
                    {finalIsLoading && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <Skeleton className="h-24" />
                            <Skeleton className="h-24" />
                        </div>
                    )}
                    {!finalIsLoading && coupons && coupons.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {coupons.map(coupon => (
                                <div key={coupon.id} className="border-2 border-dashed border-primary bg-primary/10 rounded-lg p-4 flex items-center justify-between">
                                    <div>
                                        <h3 className="text-lg font-bold text-primary">{coupon.code}</h3>
                                        <p className="text-sm">{coupon.discountPercentage}% off on orders above ${coupon.minimumOrderValue}</p>
                                        <p className="text-xs text-muted-foreground">Expires: {new Date(coupon.expiryDate).toLocaleDateString()}</p>
                                    </div>
                                    <Tag className="h-8 w-8 text-primary" />
                                </div>
                            ))}
                        </div>
                    ) : (
                        !finalIsLoading && (
                            <div className="flex flex-col items-center justify-center text-center text-muted-foreground p-12 border-2 border-dashed rounded-lg">
                                <Tag className="h-16 w-16 mb-4" />
                                <p className="font-semibold">No offers available at the moment.</p>
                                <p className="text-sm">{!user ? 'Please log in to see offers.' : 'Check back later!'}</p>
                            </div>
                        )
                    )}
                </CardContent>
            </Card>
            </div>
        </main>
        <Footer />
    </div>
  );
}
