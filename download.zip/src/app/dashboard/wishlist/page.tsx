'use client';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { ProductCard } from "@/components/shared/product-card";
import { useCollection, useFirestore, useUser, useMemoFirebase } from "@/firebase";
import { collection, doc, getDocs, query, where, documentId } from "firebase/firestore";
import { Skeleton } from "@/components/ui/skeleton";
import { Heart } from "lucide-react";
import type { Product } from "@/lib/types";
import { getPlaceholderImage } from "@/lib/placeholder-images";
import { BackButton } from "@/components/shared/back-button";
import { useEffect, useState } from "react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";

type WishlistItem = {
  id: string; // This will be the product ID
  shopId: string;
};

export default function CustomerWishlistPage() {
    const firestore = useFirestore();
    const { user, isUserLoading } = useUser();
    const [products, setProducts] = useState<Product[]>([]);
    const [isProductsLoading, setIsProductsLoading] = useState(true);

    const wishlistQuery = useMemoFirebase(() => {
        if (!firestore || !user?.uid) return null;
        return collection(firestore, `customers/${user.uid}/wishlist`);
    }, [firestore, user?.uid]);

    const { data: wishlistItems, isLoading: isWishlistLoading } = useCollection<WishlistItem>(wishlistQuery);
    
    useEffect(() => {
      const fetchProducts = async () => {
        if (!firestore || !wishlistItems || wishlistItems.length === 0) {
          setIsProductsLoading(false);
          setProducts([]);
          return;
        }

        setIsProductsLoading(true);
        
        // Batch product IDs for efficient fetching from the top-level 'products' collection
        const productIds = wishlistItems.map(item => item.id);
        
        // Firestore 'in' queries are limited to 30 items per query.
        // If you expect more, you'd need to chunk the productIds array.
        const productsRef = collection(firestore, `products`);
        const q = query(productsRef, where(documentId(), 'in', productIds));

        const productSnaps = await getDocs(q);
        
        const fetchedProducts = productSnaps.docs.map(snap => {
            if (!snap.exists()) return null;
            const data = snap.data();
            const placeholder = getPlaceholderImage('product-1');
            return {
                ...data,
                id: snap.id,
                rating: 4.5 + Math.random() * 0.5,
                reviewCount: Math.floor(Math.random() * 1000) + 50,
                image: data.images?.[0] || placeholder.imageUrl,
                imageHint: placeholder.imageHint,
            } as Product;
        }).filter((p): p is Product => p !== null);

        setProducts(fetchedProducts);
        setIsProductsLoading(false);
      }
      fetchProducts();
    }, [wishlistItems, firestore]);

    const isLoading = isUserLoading || isWishlistLoading || isProductsLoading;

  return (
    <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1 bg-muted/40">
            <div className="container mx-auto py-8">
                <div className="flex items-center gap-4 mb-4">
                    <BackButton />
                    <h1 className="text-2xl font-headline font-bold">My Wishlist</h1>
                </div>
                <Card>
                    <CardHeader>
                    <CardTitle>Saved Items</CardTitle>
                    <CardDescription>Products you've saved to your wishlist will appear here.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        {isLoading && (
                            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                                <Card><CardContent className="p-0"><Skeleton className="w-full h-48" /></CardContent><CardHeader><Skeleton className="h-6 w-3/4 mb-2" /><Skeleton className="h-4 w-1/2" /></CardHeader></Card>
                                <Card><CardContent className="p-0"><Skeleton className="w-full h-48" /></CardContent><CardHeader><Skeleton className="h-6 w-3/4 mb-2" /><Skeleton className="h-4 w-1/2" /></CardHeader></Card>
                            </div>
                        )}
                        {!isLoading && products.length === 0 && (
                            <div className="flex flex-col items-center justify-center text-center text-muted-foreground p-12 border-2 border-dashed rounded-lg">
                                <Heart className="h-16 w-16 mb-4" />
                                <p className="font-semibold">Your wishlist is empty.</p>
                                <p className="text-sm">Start browsing and add items you love!</p>
                            </div>
                        )}
                        {!isLoading && products.length > 0 && (
                            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                            {products.map(product => <ProductCard key={product.id} product={product} />)}
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>
        </main>
        <Footer />
    </div>
  );
}
