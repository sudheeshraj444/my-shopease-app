'use client';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { useDoc, useFirestore, useUser, useMemoFirebase } from "@/firebase";
import { doc } from "firebase/firestore";
import { Skeleton } from "@/components/ui/skeleton";
import { Wallet, Landmark } from "lucide-react";
import { BackButton } from "@/components/shared/back-button";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";

export default function CustomerWalletPage() {
    const firestore = useFirestore();
    const { user } = useUser();
    const customerId = user?.uid;

    const customerRef = useMemoFirebase(() => {
        if (!firestore || !customerId) return null;
        return doc(firestore, 'customers', customerId);
    }, [firestore, customerId]);

    const { data: customer, isLoading } = useDoc(customerRef);

  return (
    <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1 bg-muted/40">
            <div className="container mx-auto py-8">
                <div className="flex items-center gap-4 mb-4">
                    <BackButton />
                    <h1 className="text-2xl font-headline font-bold">My Wallet</h1>
                </div>
                <Card>
                    <CardHeader>
                    <CardTitle>Wallet Overview</CardTitle>
                    <CardDescription>Your cashback, refunds, and wallet balance will be shown here.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        {isLoading ? (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <Skeleton className="h-32" />
                                <Skeleton className="h-32" />
                            </div>
                        ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="bg-primary text-primary-foreground p-6 rounded-lg flex items-center gap-4">
                                    <Wallet className="h-12 w-12" />
                                    <div>
                                        <p className="text-sm">Wallet Balance</p>
                                        <p className="text-3xl font-bold">${(customer?.walletBalance ?? 0).toFixed(2)}</p>
                                    </div>
                                </div>
                                <div className="bg-secondary text-secondary-foreground p-6 rounded-lg flex items-center gap-4">
                                    <Landmark className="h-12 w-12" />
                                    <div>
                                        <p className="text-sm">Loyalty Points</p>
                                        <p className="text-3xl font-bold">{customer?.loyaltyPoints ?? 0}</p>
                                    </div>
                                </div>
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>
        </main>
        <Footer />
    </div>
  );
}
