'use client';
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import Link from "next/link";
import { CouponSuggester } from "@/components/customer/coupon-suggester";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { ArrowLeft, Trash2 } from "lucide-react";
import { useCartStore } from "@/lib/cart-store";
import { useEffect, useState } from "react";

export default function CartPage() {
  const { items: cartItems, updateQuantity, removeItem } = useCartStore();
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const cartValue = cartItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const shippingCost = cartValue > 0 ? 5.00 : 0;
  const tax = cartValue > 0 ? cartValue * 0.08 : 0; // 8% tax
  const total = cartValue + shippingCost + tax;
  
  if (!isClient) {
      return null;
  }

  return (
    <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1 bg-muted/40">
            <div className="container mx-auto py-8">
                <div className="flex justify-between items-center mb-6">
                    <h1 className="text-3xl font-bold font-headline">Shopping Cart</h1>
                     <Button variant="outline" asChild>
                        <Link href="/">
                            <ArrowLeft className="mr-2 h-4 w-4" />
                            Continue Shopping
                        </Link>
                    </Button>
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2">
                        <Card>
                             <CardHeader>
                                <CardTitle>Your Items ({cartItems.length})</CardTitle>
                            </CardHeader>
                            <CardContent className="p-6 space-y-6">
                                {cartItems.length === 0 && (
                                    <div className="text-center text-muted-foreground py-12">
                                        <p>Your cart is empty.</p>
                                    </div>
                                )}
                                {cartItems.map(item => (
                                    <div key={item.product.id} className="flex items-start gap-4">
                                        <div className="relative h-24 w-24 rounded-md overflow-hidden">
                                            <Image src={item.product.image} alt={item.product.name} fill className="object-cover" data-ai-hint={item.product.imageHint}/>
                                        </div>
                                        <div className="flex-1">
                                            <h3 className="font-semibold">{item.product.name}</h3>
                                            <p className="text-lg font-semibold">${item.product.price.toFixed(2)}</p>
                                            <div className="flex items-center gap-2 mt-2">
                                                <Input 
                                                    type="number" 
                                                    value={item.quantity} 
                                                    onChange={(e) => updateQuantity(item.product.id, parseInt(e.target.value))}
                                                    className="w-20" 
                                                    min="1" 
                                                />
                                            </div>
                                        </div>
                                        <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => removeItem(item.product.id)}>
                                            <Trash2 className="h-5 w-5" />
                                        </Button>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>
                    </div>
                    <div>
                        <Card>
                            <CardHeader>
                                <CardTitle>Order Summary</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="flex justify-between">
                                    <span>Subtotal</span>
                                    <span>${cartValue.toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span>Shipping</span>
                                    <span>${shippingCost.toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span>Tax</span>
                                    <span>${tax.toFixed(2)}</span>
                                </div>
                                <Separator />
                                <div className="flex justify-between font-bold text-lg">
                                    <span>Total</span>
                                    <span>${total.toFixed(2)}</span>
                                </div>
                                {cartValue > 0 && <CouponSuggester cartValue={cartValue} />}
                            </CardContent>
                            <CardFooter>
                                <Button className="w-full" asChild disabled={cartItems.length === 0}>
                                    <Link href="/checkout">Proceed to Checkout</Link>
                                </Button>
                            </CardFooter>
                        </Card>
                    </div>
                </div>
            </div>
        </main>
        <Footer />
    </div>
  );
}
