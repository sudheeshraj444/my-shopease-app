'use client';
import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/shared/logo";
import Link from "next/link";
import { useAuth, useUser } from '@/firebase';
import { RecaptchaVerifier, signInWithPhoneNumber, ConfirmationResult } from 'firebase/auth';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Check, ChevronsUpDown } from 'lucide-react';
import { useCartStore } from '@/lib/cart-store';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { countries } from '@/lib/countries';
import { useSettingsStore } from '@/lib/settings-store';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { cn } from '@/lib/utils';


export default function LoginPage() {
    const auth = useAuth();
    const { user, isUserLoading } = useUser();
    const router = useRouter();
    const { toast } = useToast();
    const { redirectUrl, setRedirectUrl } = useCartStore();
    const { setCountryAndCurrency } = useSettingsStore();

    const [nationalNumber, setNationalNumber] = useState('');
    const [selectedCountryCode, setSelectedCountryCode] = useState('US'); // Default to US
    const [otp, setOtp] = useState('');
    const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [isOtpSent, setIsOtpSent] = useState(false);
    const [authError, setAuthError] = useState<string | null>(null);
    const [isCountryPopoverOpen, setIsCountryPopoverOpen] = useState(false);

    const recaptchaVerifierRef = useRef<RecaptchaVerifier | null>(null);

    const selectedCountry = countries.find(c => c.code === selectedCountryCode);
    const fullPhoneNumber = `${selectedCountry?.dial_code}${nationalNumber}`;
    
    useEffect(() => {
        if (!isUserLoading && user) {
             const finalRedirect = redirectUrl || '/select-role';
             setRedirectUrl(null);
             router.replace(finalRedirect);
        }
    }, [user, isUserLoading, router, redirectUrl, setRedirectUrl]);

    const setupRecaptcha = () => {
        if (!auth || recaptchaVerifierRef.current) return;

        recaptchaVerifierRef.current = new RecaptchaVerifier(auth, 'recaptcha-container', {
            'size': 'normal',
            'callback': (response: any) => {
                 setAuthError(null);
            },
            'expired-callback': () => {
                toast({ variant: 'destructive', title: 'reCAPTCHA Expired', description: 'Please solve the reCAPTCHA again.' });
            }
        });
        recaptchaVerifierRef.current.render();
    };
    
    useEffect(() => {
        if (!isOtpSent && auth) {
           setupRecaptcha();
        }
    }, [isOtpSent, auth]);


    const handleSendOtp = async () => {
        setAuthError(null);
        if (!auth || !recaptchaVerifierRef.current) {
            toast({ variant: 'destructive', title: 'Error', description: 'Authentication service not ready. Please refresh.' });
            return;
        }
        if (!nationalNumber || !/^\d{7,15}$/.test(nationalNumber)) {
            toast({ variant: 'destructive', title: 'Invalid Phone Number', description: 'Please enter a valid phone number.' });
            return;
        }
        setIsLoading(true);
        try {
            const confirmation = await signInWithPhoneNumber(auth, fullPhoneNumber, recaptchaVerifierRef.current);
            setConfirmationResult(confirmation);
            setIsOtpSent(true);
            toast({ title: 'OTP Sent', description: `An OTP has been sent to ${fullPhoneNumber}.` });
        } catch (error: any) {
            console.error('Error sending OTP:', error);
             if (error.code === 'auth/operation-not-allowed') {
                setAuthError('Phone Number sign-in is not enabled for this Firebase project.');
            } else {
                toast({ variant: 'destructive', title: 'Failed to Send OTP', description: `Please check the number (${fullPhoneNumber}) and reCAPTCHA, then try again.` });
            }
        } finally {
            setIsLoading(false);
        }
    };

    const handleVerifyOtp = async () => {
        if (!confirmationResult) {
            toast({ variant: 'destructive', title: 'Error', description: 'Please request an OTP first.' });
            return;
        }
        if (otp.length !== 6) {
             toast({ variant: 'destructive', title: 'Invalid OTP', description: 'Please enter the 6-digit OTP.' });
             return;
        }

        setIsLoading(true);
        try {
            await confirmationResult.confirm(otp);
            if (selectedCountry) {
              setCountryAndCurrency(selectedCountry.name, selectedCountry.currency);
            }
            toast({ title: 'Login Successful!', description: 'Welcome to ShopEase!' });
        } catch (error) {
            console.error('Error verifying OTP:', error);
            toast({ variant: 'destructive', title: 'Invalid OTP', description: 'The code you entered is incorrect. Please try again.' });
        } finally {
            setIsLoading(false);
        }
    };


  return (
    <div className="flex min-h-screen items-center justify-center bg-secondary p-4">
      <Card className="mx-auto w-full max-w-sm">
        <CardHeader className="text-center">
          <div className="mb-4 flex justify-center">
            <Logo />
          </div>
          <CardTitle className="text-2xl font-headline">Login with Phone</CardTitle>
          <CardDescription>
            {isOtpSent ? `Enter the OTP sent to ${fullPhoneNumber}` : 'Select your country and enter your phone number'}
          </CardDescription>
        </CardHeader>
        <CardContent>
            {authError && (
                 <Alert variant="destructive" className="mb-4">
                    <AlertTitle>Configuration Error</AlertTitle>
                    <AlertDescription>
                        {authError}
                        <br />
                        <a 
                            href="https://console.firebase.google.com/project/_/authentication/providers" 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="underline font-bold"
                        >
                            Please enable it in the Firebase Console.
                        </a>
                    </AlertDescription>
                </Alert>
            )}
          <div className="grid gap-4">
            {!isOtpSent ? (
                 <>
                    <div className="grid gap-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <div className="flex items-center gap-2">
                            <Popover open={isCountryPopoverOpen} onOpenChange={setIsCountryPopoverOpen}>
                                <PopoverTrigger asChild>
                                    <Button
                                    variant="outline"
                                    role="combobox"
                                    aria-expanded={isCountryPopoverOpen}
                                    className="w-[150px] justify-between"
                                    >
                                    {selectedCountry ? (
                                        <>{selectedCountry.flag} {selectedCountry.dial_code}</>
                                    ) : (
                                        "Select country"
                                    )}
                                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-[250px] p-0">
                                    <Command>
                                    <CommandInput placeholder="Search country..." />
                                    <CommandList>
                                        <CommandEmpty>No country found.</CommandEmpty>
                                        <CommandGroup>
                                        {countries.map((country) => (
                                            <CommandItem
                                            key={country.code}
                                            value={`${country.name} ${country.dial_code}`}
                                            onSelect={() => {
                                                setSelectedCountryCode(country.code)
                                                setIsCountryPopoverOpen(false)
                                            }}
                                            >
                                            <Check
                                                className={cn(
                                                "mr-2 h-4 w-4",
                                                selectedCountryCode === country.code ? "opacity-100" : "opacity-0"
                                                )}
                                            />
                                            <span>{country.flag}</span>
                                            <span className="ml-2 mr-4">{country.name}</span>
                                            <span className="ml-auto text-muted-foreground">{country.dial_code}</span>
                                            </CommandItem>
                                        ))}
                                        </CommandGroup>
                                    </CommandList>
                                    </Command>
                                </PopoverContent>
                            </Popover>
                            <Input
                                id="phone"
                                type="tel"
                                placeholder="5551234567"
                                required
                                value={nationalNumber}
                                onChange={(e) => setNationalNumber(e.target.value.replace(/\D/g, ''))}
                                disabled={isLoading}
                            />
                        </div>
                    </div>
                     <div id="recaptcha-container" className="flex justify-center"></div>
                    <Button onClick={handleSendOtp} className="w-full" disabled={isLoading}>
                         {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Send OTP
                    </Button>
                 </>
            ) : (
                <>
                    <div className="grid gap-2">
                        <Label htmlFor="otp">OTP</Label>
                        <Input 
                            id="otp" 
                            type="text" 
                            placeholder="123456" 
                            value={otp}
                            onChange={(e) => setOtp(e.target.value)}
                            disabled={isLoading}
                            maxLength={6}
                        />
                    </div>
                    <Button onClick={handleVerifyOtp} className="w-full" disabled={isLoading}>
                        {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Login with OTP
                    </Button>
                     <Button variant="link" size="sm" onClick={() => { setIsOtpSent(false); setConfirmationResult(null); setAuthError(null); }}>
                        Use a different phone number
                    </Button>
                </>
            )}
          </div>
          <div className="mt-4 text-center text-sm">
            By logging in, you agree to our{" "}
            <Link href="#" className="underline">
              Terms of Service
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
