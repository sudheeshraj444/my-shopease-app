'use client';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { useDoc, useFirestore, useMemoFirebase } from '@/firebase';
import { doc } from 'firebase/firestore';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { KeyRound, ShieldCheck } from 'lucide-react';
import { BackButton } from '@/components/shared/back-button';

export default function OrderDetailPage({ params }: { params: { orderId: string } }) {
  const firestore = useFirestore();
  const { orderId } = params;

  const orderRef = useMemoFirebase(() => {
    if (!firestore || !orderId) return null;
    return doc(firestore, 'orders', orderId);
  }, [firestore, orderId]);

  const { data: order, isLoading, error } = useDoc(orderRef);

   if (isLoading) {
    return (
        <div className="flex min-h-screen flex-col">
            <Header />
            <main className="flex-1 bg-muted/40">
                <div className="container mx-auto py-8">
                    <div className="flex items-center gap-4 mb-4">
                        <BackButton />
                         <Skeleton className="h-8 w-48" />
                    </div>
                    <Card>
                        <CardHeader>
                            <Skeleton className="h-6 w-3/4 mb-2" />
                            <Skeleton className="h-4 w-1/2" />
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <Skeleton className="h-10" />
                            <Skeleton className="h-20" />
                             <Skeleton className="h-24" />
                        </CardContent>
                    </Card>
                </div>
            </main>
            <Footer />
        </div>
    )
  }

  if (error || !order) {
    return (
        <div className="flex min-h-screen flex-col">
            <Header />
            <main className="flex-1 bg-muted/40">
                <div className="container mx-auto py-8">
                    <div className="flex items-center gap-4 mb-4">
                        <BackButton />
                        <h1 className="text-2xl font-headline font-bold text-destructive">Error</h1>
                    </div>
                    <Card>
                        <CardHeader>
                            <CardTitle>Order Not Found</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p>There was an error loading this order, or you do not have permission to view it.</p>
                        </CardContent>
                    </Card>
                </div>
            </main>
            <Footer />
        </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1 bg-muted/40">
            <div className="container mx-auto py-8">
              <div className="flex items-center gap-4 mb-4">
                <BackButton />
                <h1 className="text-2xl font-headline font-bold">
                  Order #{orderId.substring(0, 6)}
                </h1>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Order Details</CardTitle>
                    <CardDescription>
                      Placed on {new Date(order.orderDate).toLocaleDateString()}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Status</span>
                      <span className="font-semibold">{order.status}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Total</span>
                      <span className="font-semibold">${order.totalAmount.toFixed(2)}</span>
                    </div>
                    <Separator />
                    <div className="space-y-1">
                        <p className="text-muted-foreground">Shipping Address</p>
                        <p>{order.shippingAddress}</p>
                    </div>
                     <div className="space-y-1">
                        <p className="text-muted-foreground">Payment Method</p>
                        <p>{order.paymentMethod}</p>
                    </div>
                  </CardContent>
                </Card>

                {order.deliveryOtp ? (
                  <Card className="bg-gradient-to-br from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20">
                    <CardHeader>
                        <div className="flex items-center gap-2">
                            <KeyRound className="h-6 w-6 text-primary" />
                            <CardTitle>Your Delivery OTP</CardTitle>
                        </div>
                      <CardDescription>
                        Provide this code to the delivery person to confirm your order. Do not share it with anyone else.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="flex flex-col items-center justify-center gap-2">
                      <p className="text-5xl font-bold tracking-widest bg-muted/50 px-4 py-2 rounded-lg">
                        {order.deliveryOtp}
                      </p>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground mt-2">
                        <ShieldCheck className="h-3 w-3" />
                        <span>Secure Delivery</span>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                    <Card>
                        <CardHeader>
                            <CardTitle>Delivery OTP</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-muted-foreground text-center py-8">Your delivery OTP will be generated once the seller packs your order.</p>
                        </CardContent>
                    </Card>
                )}
              </div>
            </div>
        </main>
        <Footer />
    </div>
  );
}
