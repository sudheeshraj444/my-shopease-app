'use client';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { useCollection, useFirestore, useUser, useMemoFirebase } from "@/firebase";
import { collection, query, where } from "firebase/firestore";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useRouter } from "next/navigation";
import { useMemo } from "react";
import { BackButton } from '@/components/shared/back-button';

export default function OrdersPage() {
  const firestore = useFirestore();
  const { user } = useUser();
  const router = useRouter();
  const customerId = user?.uid;

  const ordersQuery = useMemoFirebase(() => {
    if (!firestore || !customerId) return null;
    return query(
        collection(firestore, 'orders'),
        where('members', 'array-contains', customerId)
    );
  }, [firestore, customerId]);

  const { data: orders, isLoading } = useCollection(ordersQuery);

  const sortedOrders = useMemo(() => {
    if (!orders) return [];
    return [...orders].sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime());
  }, [orders]);

  const handleRowClick = (orderId: string) => {
    router.push(`/orders/${orderId}`);
  };

  return (
    <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1 bg-muted/40">
            <div className="container mx-auto py-8">
                <div className="flex items-center gap-4 mb-4">
                    <BackButton />
                    <h1 className="text-3xl font-headline font-bold">My Orders</h1>
                </div>
                <Card>
                    <CardHeader>
                    <CardTitle>Order History</CardTitle>
                    <CardDescription>A list of your past and current orders. Click an order to view details.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Order ID</TableHead>
                                    <TableHead>Date</TableHead>
                                    <TableHead>Total</TableHead>
                                    <TableHead>Status</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {isLoading && (
                                    Array.from({ length: 3 }).map((_, i) => (
                                    <TableRow key={i}>
                                        <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                                        <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                                        <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                                        <TableCell><Skeleton className="h-6 w-20 rounded-full" /></TableCell>
                                    </TableRow>
                                    ))
                                )}
                                {!isLoading && sortedOrders?.map(order => (
                                    <TableRow key={order.id} className="cursor-pointer hover:bg-muted/50" onClick={() => handleRowClick(order.id)}>
                                        <TableCell className="font-medium">
                                            #{order.id.substring(0, 6)}...
                                        </TableCell>
                                        <TableCell>
                                            {new Date(order.orderDate).toLocaleDateString()}
                                        </TableCell>
                                        <TableCell>
                                            ${order.totalAmount.toFixed(2)}
                                        </TableCell>
                                        <TableCell>
                                            <Badge variant={order.status === 'Delivered' ? 'default' : 'secondary'}>{order.status}</Badge>
                                        </TableCell>
                                    </TableRow>
                                ))}
                                {!isLoading && sortedOrders?.length === 0 && (
                                    <TableRow>
                                        <TableCell colSpan={4} className="text-center text-muted-foreground py-12">
                                            You haven't placed any orders yet.
                                        </TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </div>
        </main>
        <Footer />
    </div>
  );
}
