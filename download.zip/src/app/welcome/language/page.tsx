'use client';

import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useSettingsStore } from '@/lib/settings-store';
import { Globe } from 'lucide-react';

const languages = ['English', 'Español', 'Français', 'हिंदी', 'Deutsch'];

export default function LanguageSelectionPage() {
  const router = useRouter();
  const { setLanguage, completeOnboarding } = useSettingsStore();

  const handleSelectLanguage = (lang: string) => {
    setLanguage(lang);
    completeOnboarding();
    router.push('/login');
  };

  return (
    <Card className="w-full max-w-lg">
      <CardHeader className="text-center">
        <div className="mx-auto bg-primary/10 p-3 rounded-full mb-4 w-fit">
            <Globe className="h-8 w-8 text-primary" />
        </div>
        <CardTitle>Select Your Language</CardTitle>
        <CardDescription>Choose the language for your shopping experience.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 gap-4">
          {languages.map((lang) => (
            <Button
              key={lang}
              variant="outline"
              size="lg"
              onClick={() => handleSelectLanguage(lang)}
            >
              {lang}
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
