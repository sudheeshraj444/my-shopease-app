'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useSettingsStore } from '@/lib/settings-store';
import { countries, CountryData } from '@/lib/countries';
import { Check, MapPinned } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { cn } from '@/lib/utils';

export default function CountrySelectionPage() {
  const router = useRouter();
  const { setCountryAndCurrency, completeOnboarding } = useSettingsStore();
  const [selectedCountry, setSelectedCountry] = useState<CountryData | null>(null);

  const handleSelectCountry = (country: CountryData) => {
    setSelectedCountry(country);
    setCountryAndCurrency(country.name, country.currency);
  };

  const handleContinue = () => {
    if (selectedCountry) {
      completeOnboarding();
      router.push('/login');
    }
  };

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader className="text-center">
        <div className="mx-auto bg-primary/10 p-3 rounded-full mb-4 w-fit">
            <MapPinned className="h-8 w-8 text-primary" />
        </div>
        <CardTitle>Select Your Country</CardTitle>
        <CardDescription>This will help us determine your currency and shipping options.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {countries.map((country) => (
            <button
              key={country.code}
              onClick={() => handleSelectCountry(country)}
              className={cn(
                "p-4 border rounded-lg flex flex-col items-center justify-center gap-2 transition-all",
                selectedCountry?.code === country.code
                  ? "border-primary ring-2 ring-primary ring-offset-2"
                  : "hover:border-primary/50"
              )}
            >
              <span className="text-4xl">{country.flag}</span>
              <span className="font-medium text-sm text-center">{country.name}</span>
            </button>
          ))}
        </div>

        {selectedCountry && (
          <div className="space-y-4">
            <Alert>
              <Check className="h-4 w-4" />
              <AlertTitle>Currency Updated!</AlertTitle>
              <AlertDescription>
                Your store currency has been set to <span className="font-semibold">{selectedCountry.currency}</span>.
              </AlertDescription>
            </Alert>
            <Button size="lg" className="w-full" onClick={handleContinue}>
              Continue to Login
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
