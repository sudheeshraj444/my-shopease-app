export const firebaseConfig = {
  "projectId": "studio-1685069315-d776b",
  "appId": "1:308895719324:web:4558376625d73ec40cf259",
  "apiKey": "AIzaSyDTNOvSAF39AMd9nJrjSmYBQ5_CPziKm38",
  "authDomain": "studio-1685069315-d776b.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "308895719324"
};
