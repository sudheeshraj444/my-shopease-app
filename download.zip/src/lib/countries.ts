export type CountryData = {
  name: string;
  code: string;
  currency: string;
  flag: string;
  dial_code: string;
};

export const countries: CountryData[] = [
  { name: 'United States', code: 'US', currency: 'USD', flag: '🇺🇸', dial_code: '+1' },
  { name: 'India', code: 'IN', currency: 'INR', flag: '🇮🇳', dial_code: '+91' },
  { name: 'United Kingdom', code: 'GB', currency: 'GBP', flag: '🇬🇧', dial_code: '+44' },
  { name: 'Canada', code: 'CA', currency: 'CAD', flag: '🇨🇦', dial_code: '+1' },
  { name: 'Australia', code: 'AU', currency: 'AUD', flag: '🇦🇺', dial_code: '+61' },
  { name: 'Germany', code: 'DE', currency: 'EUR', flag: '🇩🇪', dial_code: '+49' },
  { name: 'France', code: 'FR', currency: 'EUR', flag: '🇫🇷', dial_code: '+33' },
  { name: 'Japan', code: 'JP', currency: 'JPY', flag: '🇯🇵', dial_code: '+81' },
];
