'use client';
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

type SettingsState = {
  language: string | null;
  country: string | null;
  currency: string | null;
  isOnboardingComplete: boolean;
  setLanguage: (language: string) => void;
  setCountryAndCurrency: (country: string, currency: string) => void;
  completeOnboarding: () => void;
  resetOnboarding: () => void; // For testing
};

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      language: null,
      country: null,
      currency: null,
      isOnboardingComplete: false,
      setLanguage: (language) => set({ language }),
      setCountryAndCurrency: (country, currency) => set({ country, currency }),
      completeOnboarding: () => set({ isOnboardingComplete: true }),
      resetOnboarding: () => set({ language: null, country: null, currency: null, isOnboardingComplete: false }),
    }),
    {
      name: 'settings-storage',
      storage: createJSONStorage(() => localStorage),
    }
  )
);
