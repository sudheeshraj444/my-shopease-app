export type Product = {
  id: string;
  shopOwnerId: string;
  name: string;
  description: string;
  price: number;
  stockQuantity: number;
  rating: number;
  reviewCount: number;
  image: string;
  images: string[];
  imageHint: string;
  category: string;
};

export type ShopOwner = {
    id: string;
    shopName: string;
    address: string;
    location: string;
    shopImageUrl: string;
};

export type Category = {
  id: string;
  name:string;
  image: string;
  imageHint: string;
};

export type UserRole = "customer" | "seller" | "delivery";

export type Order = {
  id: string;
  customerName: string;
  productName: string;
  pickupLocation: string;
  deliveryLocation: string;
  status: "Assigned" | "Picked Up" | "On the Way" | "Delivered";
  paymentType: "COD" | "Prepaid";
  deliveryOtp?: string;
};

    
