import data from './placeholder-images.json';

export type ImagePlaceholder = {
  id: string;
  description: string;
  imageUrl: string;
  imageHint: string;
};

export const placeholderImages: ImagePlaceholder[] = data.placeholderImages;

export function getPlaceholderImage(id: string): ImagePlaceholder {
  const image = placeholderImages.find(img => img.id === id);
  if (!image) {
    // Return a default or throw an error
    return {
      id: 'not-found',
      description: 'Image not found',
      imageUrl: 'https://picsum.photos/seed/not-found/400/400',
      imageHint: 'placeholder',
    };
  }
  return image;
}
