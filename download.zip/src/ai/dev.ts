import { config } from 'dotenv';
config();

import '@/ai/flows/auto-translate-product-descriptions.ts';
import '@/ai/flows/suggest-best-coupon.ts';