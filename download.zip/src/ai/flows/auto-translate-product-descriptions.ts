'use server';
/**
 * @fileOverview This file defines a Genkit flow for automatically translating product descriptions into multiple languages.
 *
 * The flow takes a product description and a list of target languages as input, and returns a
 * map of translated descriptions, keyed by language code.  It exports:
 * - `autoTranslateProductDescriptions` - A function that handles the product description translation process.
 * - `AutoTranslateProductDescriptionsInput` - The input type for the autoTranslateProductDescriptions function.
 * - `AutoTranslateProductDescriptionsOutput` - The return type for the autoTranslateProductDescriptions function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AutoTranslateProductDescriptionsInputSchema = z.object({
  description: z.string().describe('The product description to translate.'),
  targetLanguages: z
    .array(z.string())
    .describe('An array of language codes to translate the description into.'),
});
export type AutoTranslateProductDescriptionsInput = z.infer<
  typeof AutoTranslateProductDescriptionsInputSchema
>;

const AutoTranslateProductDescriptionsOutputSchema = z.record(
  z.string(),
  z.string()
);
export type AutoTranslateProductDescriptionsOutput = z.infer<
  typeof AutoTranslateProductDescriptionsOutputSchema
>;

export async function autoTranslateProductDescriptions(
  input: AutoTranslateProductDescriptionsInput
): Promise<AutoTranslateProductDescriptionsOutput> {
  return autoTranslateProductDescriptionsFlow(input);
}

const translatePrompt = ai.definePrompt({
  name: 'translatePrompt',
  input: {
    schema: z.object({
      description: z.string(),
      targetLanguage: z.string(),
    }),
  },
  output: {schema: z.string()},
  prompt: `Translate the following product description into {{{targetLanguage}}}:\n\n{{{description}}}`,
});

const autoTranslateProductDescriptionsFlow = ai.defineFlow(
  {
    name: 'autoTranslateProductDescriptionsFlow',
    inputSchema: AutoTranslateProductDescriptionsInputSchema,
    outputSchema: AutoTranslateProductDescriptionsOutputSchema,
  },
  async input => {
    const translations: AutoTranslateProductDescriptionsOutput = {};
    for (const language of input.targetLanguages) {
      const {output} = await translatePrompt({
        description: input.description,
        targetLanguage: language,
      });
      translations[language] = output!;
    }
    return translations;
  }
);
