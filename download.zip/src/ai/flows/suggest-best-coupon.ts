'use server';

/**
 * @fileOverview This file implements the AI flow for suggesting the best coupon to use for a customer's cart.
 *
 * - suggestBestCoupon - A function that suggests the best coupon for a given cart.
 * - SuggestBestCouponInput - The input type for the suggestBestCoupon function.
 * - SuggestBestCouponOutput - The return type for the suggestBestCoupon function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestBestCouponInputSchema = z.object({
  cartValue: z.number().describe('The total value of the items in the cart.'),
  availableCoupons: z.array(z.string()).describe('An array of available coupon codes.'),
  userLoyaltyPoints: z.number().describe('The number of loyalty points the user has.'),
});
export type SuggestBestCouponInput = z.infer<typeof SuggestBestCouponInputSchema>;

const SuggestBestCouponOutputSchema = z.object({
  bestCoupon: z.string().describe('The best coupon code to use for the cart.'),
  reason: z.string().describe('The reason why this coupon is the best choice.'),
});
export type SuggestBestCouponOutput = z.infer<typeof SuggestBestCouponOutputSchema>;

export async function suggestBestCoupon(input: SuggestBestCouponInput): Promise<SuggestBestCouponOutput> {
  return suggestBestCouponFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestBestCouponPrompt',
  input: {schema: SuggestBestCouponInputSchema},
  output: {schema: SuggestBestCouponOutputSchema},
  prompt: `You are an expert in recommending the best coupon for e-commerce purchases.

  Given the following information about the user's cart and available coupons, determine the best coupon to use and explain your reasoning.

  Cart Value: {{{cartValue}}}
  Available Coupons: {{#each availableCoupons}}{{{this}}}{{#unless @last}}, {{/unless}}{{/each}}
  User Loyalty Points: {{{userLoyaltyPoints}}}

  Consider factors such as the coupon value, minimum purchase requirements, and user loyalty points when making your recommendation.
  The output should only contain the best coupon and the reason. Do not include any other text.`,
});

const suggestBestCouponFlow = ai.defineFlow(
  {
    name: 'suggestBestCouponFlow',
    inputSchema: SuggestBestCouponInputSchema,
    outputSchema: SuggestBestCouponOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
