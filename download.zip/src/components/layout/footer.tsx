'use client';

import { Logo } from "@/components/shared/logo";
import Link from "next/link";
import { usePathname } from "next/navigation";

export function Footer() {
  const pathname = usePathname();
  const isHomePage = pathname === '/';

  const SimpleFooter = () => (
    <footer className="border-t bg-muted/40">
      <div className="container py-8 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} ShopEase. All rights reserved.
      </div>
    </footer>
  );

  const FullFooter = () => (
     <footer className="border-t bg-muted/40">
      <div className="container py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
          <div className="col-span-2 lg:col-span-2">
            <Logo />
            <p className="mt-4 text-sm text-muted-foreground">Your one-stop shop for everything you need, delivered with speed and care.</p>
          </div>
          <div>
            <h4 className="font-semibold font-headline">Shop</h4>
            <ul className="mt-4 space-y-2">
              <li><Link href="/categories/electronics" className="text-sm text-muted-foreground hover:text-foreground">Electronics</Link></li>
              <li><Link href="/categories/fashion" className="text-sm text-muted-foreground hover:text-foreground">Fashion</Link></li>
              <li><Link href="/categories/home" className="text-sm text-muted-foreground hover:text-foreground">Home Goods</Link></li>
              <li><Link href="/categories/grocery" className="text-sm text-muted-foreground hover:text-foreground">Grocery</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold font-headline">Support</h4>
            <ul className="mt-4 space-y-2">
              <li><Link href="#" className="text-sm text-muted-foreground hover:text-foreground">Contact Us</Link></li>
              <li><Link href="#" className="text-sm text-muted-foreground hover:text-foreground">FAQ</Link></li>
              <li><Link href="#" className="text-sm text-muted-foreground hover:text-foreground">Shipping</Link></li>
              <li><Link href="#" className="text-sm text-muted-foreground hover:text-foreground">Returns</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold font-headline">Legal</h4>
            <ul className="mt-4 space-y-2">
              <li><Link href="#" className="text-sm text-muted-foreground hover:text-foreground">Privacy Policy</Link></li>
              <li><Link href="#" className="text-sm text-muted-foreground hover:text-foreground">Terms of Service</Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t pt-8 text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} ShopEase. All rights reserved.
        </div>
      </div>
    </footer>
  );

  if (isHomePage) {
    return <FullFooter />;
  }

  // A limited set of pages should not show a footer at all
  const noFooterPages = [
    '/login',
    '/select-role',
    '/seller/dashboard',
    '/delivery/dashboard'
  ];
  if (noFooterPages.some(p => pathname.startsWith(p))) {
    return null;
  }
  
  return <SimpleFooter />;
}
