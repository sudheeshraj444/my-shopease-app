'use client';
import Link from 'next/link';
import { Bell, Check } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  useCollection,
  useFirestore,
  useUser,
  useMemoFirebase,
  updateDocumentNonBlocking,
} from '@/firebase';
import { collection, query, where, doc } from 'firebase/firestore';
import { Skeleton } from '../ui/skeleton';
import { useMemo } from 'react';

interface Notification {
  id: string;
  message: string;
  link: string;
  read: boolean;
  createdAt: string; // ISO string
}

export function Notifications() {
  const firestore = useFirestore();
  const { user } = useUser();
  const userId = user?.uid;

  const notificationsQuery = useMemoFirebase(() => {
    if (!firestore || !userId) return null;
    // The query MUST match the security rule exactly, which only allows filtering by userId.
    // Sorting must be done on the client.
    return query(
      collection(firestore, 'notifications'),
      where('userId', '==', userId)
    );
  }, [firestore, userId]);

  const { data: notifications, isLoading } =
    useCollection<Notification>(notificationsQuery);

  const sortedNotifications = useMemo(() => {
    if (!notifications) return [];
    // Sort on the client-side after fetching
    return [...notifications].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [notifications]);

  const unreadCount = notifications?.filter((n) => !n.read).length ?? 0;

  const handleMarkAsRead = (notificationId: string) => {
    if (!firestore) return;
    const notifRef = doc(firestore, 'notifications', notificationId);
    updateDocumentNonBlocking(notifRef, { read: true });
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge className="absolute -top-1 -right-1 h-5 w-5 justify-center p-0">
              {unreadCount}
            </Badge>
          )}
          <span className="sr-only">Notifications</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-80" align="end">
        <DropdownMenuLabel>Notifications</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {isLoading && (
          <div className="p-2 space-y-2">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        )}
        {!isLoading &&
          (!sortedNotifications || sortedNotifications.length === 0) && (
            <p className="p-4 text-sm text-muted-foreground text-center">
              No notifications yet.
            </p>
          )}
        {!isLoading &&
          sortedNotifications &&
          sortedNotifications.map((notif) => (
            <DropdownMenuItem
              key={notif.id}
              className="flex items-start gap-2"
              asChild
            >
              <Link
                href={notif.link}
                className={`p-2 rounded-lg ${!notif.read ? 'bg-accent' : ''}`}
              >
                <div className="flex-1">
                  <p className="text-sm">{notif.message}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(notif.createdAt).toLocaleString()}
                  </p>
                </div>
                {!notif.read && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.preventDefault();
                      handleMarkAsRead(notif.id);
                    }}
                  >
                    <Check className="h-4 w-4" />
                    <span className="sr-only">Mark as read</span>
                  </Button>
                )}
              </Link>
            </DropdownMenuItem>
          ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
