'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { LogOut, Truck, Building2, User } from 'lucide-react';
import { getPlaceholderImage } from '@/lib/placeholder-images';
import { useUser, useDoc, useFirestore, useMemoFirebase, useAuth } from '@/firebase';
import { doc } from 'firebase/firestore';

export function UserNav() {
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();
  const auth = useAuth();
  const router = useRouter();
  const userId = user?.uid;

  const customerRef = useMemoFirebase(() => {
    if (!firestore || !userId) return null;
    return doc(firestore, 'customers', userId);
  }, [firestore, userId]);
  
  const shopOwnerRef = useMemoFirebase(() => {
    if (!firestore || !userId) return null;
    return doc(firestore, 'shopOwners', userId);
  }, [firestore, userId]);
  
  const deliveryPersonRef = useMemoFirebase(() => {
    if (!firestore || !userId) return null;
    return doc(firestore, 'deliveryPersons', userId);
  }, [firestore, userId]);

  const { data: customer, isLoading: isCustomerLoading } = useDoc(customerRef);
  const { data: shopOwner, isLoading: isShopOwnerLoading } = useDoc(shopOwnerRef);
  const { data: deliveryPerson, isLoading: isDeliveryPersonLoading } = useDoc(deliveryPersonRef);

  const isLoading = isUserLoading || isCustomerLoading || isShopOwnerLoading || isDeliveryPersonLoading;

  const defaultAvatar = getPlaceholderImage('avatar');
  
  let displayName = user?.displayName || 'ShopEase User';
  // Firestore data can have more accurate names
  if (customer?.name) displayName = customer.name;
  if (shopOwner?.shopName) displayName = shopOwner.shopName;
  if (deliveryPerson?.name) displayName = deliveryPerson.name;
  
  const userImage = shopOwner?.shopImageUrl || user?.photoURL || defaultAvatar.imageUrl;

  const getFallback = () => {
    if (!displayName) return 'SE';
    return displayName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
  };

  const isCustomer = !!customer;
  const isShopOwner = !!shopOwner;
  const isDeliveryPerson = !!deliveryPerson;
  
  const handleLogout = async () => {
    if (auth) {
      await auth.signOut();
      router.push('/login');
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative h-8 w-8 rounded-full">
          <Avatar className="h-8 w-8">
            <AvatarImage
              src={userImage}
              alt="User avatar"
              data-ai-hint={defaultAvatar.imageHint}
            />
            <AvatarFallback>{getFallback()}</AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56" align="end" forceMount>
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium leading-none">
              {isLoading ? 'Loading...' : displayName}
            </p>
            <p className="text-xs leading-none text-muted-foreground">
              {user?.email || user?.phoneNumber || 'user@example.com'}
            </p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        
        {/* Role switcher */}
        {(isCustomer || isShopOwner || isDeliveryPerson) && (
          <DropdownMenuGroup>
            <DropdownMenuLabel>Switch View</DropdownMenuLabel>
            {isCustomer && (
              <DropdownMenuItem asChild>
                <Link href="/">
                  <User className="mr-2 h-4 w-4" />
                  <span>Customer View</span>
                </Link>
              </DropdownMenuItem>
            )}
            {isShopOwner && (
              <DropdownMenuItem asChild>
                <Link href="/seller/dashboard">
                  <Building2 className="mr-2 h-4 w-4" />
                  <span>Seller Dashboard</span>
                </Link>
              </DropdownMenuItem>
            )}
            {isDeliveryPerson && (
              <DropdownMenuItem asChild>
                <Link href="/delivery/dashboard">
                  <Truck className="mr-2 h-4 w-4" />
                  <span>Delivery Dashboard</span>
                </Link>
              </DropdownMenuItem>
            )}
          </DropdownMenuGroup>
        )}

        <DropdownMenuSeparator />

        <DropdownMenuItem onClick={handleLogout} className="cursor-pointer">
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
