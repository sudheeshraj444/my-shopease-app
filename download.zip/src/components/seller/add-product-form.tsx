"use client"

import { useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Languages, Upload, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { autoTranslateProductDescriptions } from "@/ai/flows/auto-translate-product-descriptions";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useFirestore, useUser, setDocumentNonBlocking, useMemoFirebase } from "@/firebase";
import { collection, doc } from "firebase/firestore";
import { getPlaceholderImage } from "@/lib/placeholder-images";
import Image from "next/image";

const productSchema = z.object({
  name: z.string().min(1, "Product name is required"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  price: z.coerce.number().min(0, "Price must be a positive number"),
  priceUnit: z.string().optional().describe("e.g. kg, piece, packet"),
  stockQuantity: z.coerce.number().int().min(0, "Stock must be a positive integer"),
  category: z.string().min(1, "Category is required."),
  images: z.array(z.string().url("Must be a valid URL")).min(1, "At least one image is required"),
});

type ProductFormData = z.infer<typeof productSchema>;

export function AddProductForm() {
  const { toast } = useToast();
  const [isTranslating, setIsTranslating] = useState(false);
  const [translations, setTranslations] = useState<Record<string, string> | null>(null);

  const firestore = useFirestore();
  const { user } = useUser();

  const { register, handleSubmit, control, watch, formState: { errors } } = useForm<ProductFormData>({
    resolver: zodResolver(productSchema),
    defaultValues: { images: [] },
  });
  
  const { fields, append, remove } = useFieldArray({ control, name: "images" });

  const descriptionValue = watch("description");

  const onSubmit = (data: ProductFormData) => {
    if (!firestore || !user?.uid) {
        toast({
            variant: "destructive",
            title: "Error",
            description: "You must be logged in to add a product.",
        });
        return;
    }
    const newProductData = {
        ...data,
        shopOwnerId: user.uid,
    };
    
    // Create a new document reference in the shop-specific collection
    const shopProductsCollection = collection(firestore, `shops/${user.uid}/products`);
    const newProductRef = doc(shopProductsCollection); // Create a new doc with a generated ID
    
    // Write to the shop-specific collection
    setDocumentNonBlocking(newProductRef, newProductData, {});
    
    // Also write to the top-level 'products' collection for global querying
    const globalProductRef = doc(firestore, 'products', newProductRef.id);
    setDocumentNonBlocking(globalProductRef, newProductData, {});

    toast({
      title: "Product Submitted!",
      description: "Your new product has been saved.",
    });
  };

  const handleTranslate = async () => {
    if (!descriptionValue || descriptionValue.length < 10) {
      toast({
        variant: "destructive",
        title: "Translation Error",
        description: "Please enter a description of at least 10 characters before translating.",
      });
      return;
    }
    setIsTranslating(true);
    try {
      const result = await autoTranslateProductDescriptions({
        description: descriptionValue,
        targetLanguages: ["Spanish", "French", "German", "Hindi"],
      });
      setTranslations(result);
      toast({
        title: "Translation Successful",
        description: "Product description has been translated.",
      });
    } catch (error) {
      console.error("Translation failed:", error);
      toast({
        variant: "destructive",
        title: "Translation Failed",
        description: "Could not translate the description. Please try again.",
      });
    } finally {
      setIsTranslating(false);
    }
  };
  
  const addRandomImage = () => {
    const randomId = Math.floor(Math.random() * 8) + 1;
    const placeholder = getPlaceholderImage(`product-${randomId}`);
    append(placeholder.imageUrl);
  };


  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Product Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name">Product Name</Label>
                <Input id="name" {...register("name")} />
                {errors.name && <p className="text-sm text-destructive mt-1">{errors.name.message}</p>}
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" {...register("description")} />
                {errors.description && <p className="text-sm text-destructive mt-1">{errors.description.message}</p>}
              </div>
               <div>
                <Label htmlFor="category">Category</Label>
                <Input id="category" {...register("category")} />
                {errors.category && <p className="text-sm text-destructive mt-1">{errors.category.message}</p>}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Pricing & Stock</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-1">
                <Label htmlFor="price">Price</Label>
                <Input id="price" type="number" step="0.01" {...register("price")} />
                {errors.price && <p className="text-sm text-destructive mt-1">{errors.price.message}</p>}
              </div>
               <div className="md:col-span-1">
                <Label htmlFor="priceUnit">Price Unit (e.g., kg, packet)</Label>
                <Input id="priceUnit" {...register("priceUnit")} placeholder="kg, packet, piece..." />
                {errors.priceUnit && <p className="text-sm text-destructive mt-1">{errors.priceUnit.message}</p>}
              </div>
              <div>
                <Label htmlFor="stock">Stock Quantity</Label>
                <Input id="stock" type="number" {...register("stockQuantity")} />
                {errors.stockQuantity && <p className="text-sm text-destructive mt-1">{errors.stockQuantity.message}</p>}
              </div>
            </CardContent>
          </Card>
        </div>
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Product Images</CardTitle>
              <CardDescription>Add up to 5 image URLs.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-2">
                  {fields.map((field, index) => (
                    <div key={field.id} className="relative">
                      <div className="aspect-square bg-muted rounded-md flex items-center justify-center text-xs text-muted-foreground overflow-hidden">
                         <Image src={field.value} alt={`Product image ${index + 1}`} fill className="object-cover" />
                      </div>
                      <Button size="icon" variant="destructive" className="absolute -top-2 -right-2 h-6 w-6 rounded-full" onClick={() => remove(index)}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
                {errors.images?.root && <p className="text-sm text-destructive mt-1">{errors.images.root.message}</p>}
                {fields.length < 5 && (
                  <Button type="button" variant="outline" className="w-full" onClick={addRandomImage}>
                    <Upload className="h-4 w-4 mr-2" />
                    Add Image
                  </Button>
                )}
                 {errors.images && !errors.images.root && <p className="text-sm text-destructive mt-1">Please enter valid image URLs.</p>}
              </div>
            </CardContent>
          </Card>
           <Card>
            <CardHeader>
              <CardTitle>AI Translations</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <Button type="button" onClick={handleTranslate} disabled={isTranslating} className="w-full">
                    <Languages className="mr-2 h-4 w-4" />
                    {isTranslating ? "Translating..." : "Auto-translate Description"}
                </Button>
                {translations && (
                    <Tabs defaultValue={Object.keys(translations)[0]}>
                        <TabsList className="grid w-full grid-cols-4">
                            {Object.keys(translations).map(lang => <TabsTrigger key={lang} value={lang}>{lang}</TabsTrigger>)}
                        </TabsList>
                        {Object.entries(translations).map(([lang, text]) => (
                            <TabsContent key={lang} value={lang}>
                                <Alert>
                                    <AlertTitle>{lang} Translation</AlertTitle>
                                    <AlertDescription className="mt-2">{text}</AlertDescription>
                                </Alert>
                            </TabsContent>
                        ))}
                    </Tabs>
                )}
            </CardContent>
          </Card>
        </div>
      </div>
      <div className="mt-6 flex justify-end">
        <Button type="submit">Save Product</Button>
      </div>
    </form>
  );
}
