'use client';
import { useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { CircleDollarSign, Package, ShoppingCart, Users } from "lucide-react";
import { useCollection, useFirestore, useUser, useMemoFirebase } from "@/firebase";
import { collection, query, where } from "firebase/firestore";
import { Skeleton } from "@/components/ui/skeleton";

export function OverviewStats() {
    const firestore = useFirestore();
    const { user } = useUser();
    const shopOwnerId = user?.uid;

    const ordersQuery = useMemoFirebase(() => {
        if (!firestore || !shopOwnerId) return null;
        return query(
            collection(firestore, 'orders'),
            where('members', 'array-contains', shopOwnerId)
        );
    }, [firestore, shopOwnerId]);

    const { data: orders, isLoading } = useCollection(ordersQuery);

    const statsData = useMemo(() => {
        if (!orders) {
            return {
                totalRevenue: 0,
                totalSales: 0,
                newCustomers: 0,
            };
        }

        const totalRevenue = orders.reduce((acc, order) => acc + order.totalAmount, 0);
        const totalSales = orders.length;
        const uniqueCustomers = new Set(orders.map(order => order.customerId)).size;

        return {
            totalRevenue,
            totalSales,
            newCustomers: uniqueCustomers,
        };
    }, [orders]);
    
    const stats = [
        { title: "Total Revenue", value: `$${statsData.totalRevenue.toFixed(2)}`, icon: CircleDollarSign, key: 'revenue' },
        { title: "Total Sales", value: `+${statsData.totalSales}`, icon: Package, key: 'sales' },
        { title: "New Customers", value: `+${statsData.newCustomers}`, icon: Users, key: 'customers' },
    ];


    return (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {isLoading ? (
                 stats.map(stat => (
                    <Card key={stat.key}>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                            <stat.icon className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <Skeleton className="h-8 w-3/4 mb-1" />
                            <Skeleton className="h-4 w-1/2" />
                        </CardContent>
                    </Card>
                ))
            ) : (
                stats.map(stat => (
                    <Card key={stat.key}>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                            <stat.icon className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{stat.value}</div>
                            <p className="text-xs text-muted-foreground">Based on all orders</p>
                        </CardContent>
                    </Card>
                ))
            )}
        </div>
    )
}
    