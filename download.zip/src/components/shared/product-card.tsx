'use client';
import Image from "next/image";
import Link from "next/link";
import { Star, Heart } from "lucide-react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import type { Product } from "@/lib/types";
import { cn } from "@/lib/utils";
import { useUser, useFirestore, setDocumentNonBlocking, deleteDocumentNonBlocking, useDoc, useMemoFirebase } from "@/firebase";
import { doc } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import { useEffect, useState } from "react";
import { useCartStore } from "@/lib/cart-store";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { user } = useUser();
  const firestore = useFirestore();
  const { toast } = useToast();
  const router = useRouter();
  const addItemToCart = useCartStore(state => state.addItem);

  // Wishlist logic
  const wishlistItemRef = useMemoFirebase(() => {
    if (!user || !firestore) return null;
    return doc(firestore, `customers/${user.uid}/wishlist/${product.id}`);
  }, [user, firestore, product.id]);

  const { data: wishlistItem, isLoading: isWishlistLoading } = useDoc(wishlistItemRef);
  const [isWishlisted, setIsWishlisted] = useState(false);

  useEffect(() => {
      setIsWishlisted(!!wishlistItem);
  }, [wishlistItem]);


  const handleWishlistToggle = async (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent navigating to product page
    if (!user || !firestore) {
      toast({ variant: "destructive", title: "Please log in", description: "You need to be logged in to manage your wishlist." });
      return;
    }
    
    // Optimistic update
    const newWishlistedState = !isWishlisted;
    setIsWishlisted(newWishlistedState);

    if (newWishlistedState) {
        // In a multi-shop setup, we need to know where the product comes from.
        const shopId = product.shopOwnerId;
        if (!shopId) {
             console.error("Product is missing shopOwnerId, cannot add to wishlist.");
             toast({ variant: "destructive", title: "Error", description: "Could not add item to wishlist." });
             setIsWishlisted(false); // Revert optimistic update
             return;
        }
        setDocumentNonBlocking(wishlistItemRef!, { shopId: shopId }, { merge: true });
        toast({ title: "Added to Wishlist", description: `${product.name} has been saved.` });
    } else {
        deleteDocumentNonBlocking(wishlistItemRef!);
        toast({ title: "Removed from Wishlist", description: `${product.name} has been removed.` });
    }
  };
  
  const handleAddToCart = (e: React.MouseEvent) => {
      e.preventDefault();
      addItemToCart(product);
  };

  const handleBuyNow = (e: React.MouseEvent) => {
      e.preventDefault();
      addItemToCart(product);
      router.push('/checkout');
  };

  return (
    <Card className="flex flex-col overflow-hidden transition-all hover:shadow-lg">
      <CardHeader className="p-0">
        <Link href={`/products/${product.id}`} className="relative aspect-square" aria-label={`View details for ${product.name}`}>
          <Image
            src={product.image}
            alt={product.name}
            fill
            className="object-cover"
            data-ai-hint={product.imageHint}
          />
          <Button
            size="icon"
            variant="secondary"
            className="absolute top-2 right-2 rounded-full h-8 w-8 bg-background/70 hover:bg-background z-10"
            aria-label="Add to wishlist"
            onClick={handleWishlistToggle}
            disabled={isWishlistLoading}
          >
            <Heart className={cn("h-4 w-4", isWishlisted && "fill-destructive text-destructive")} />
          </Button>
        </Link>
      </CardHeader>
      <CardContent className="p-4 flex-1 flex flex-col">
        <Link href={`/products/${product.id}`}>
          <h3 className="font-semibold text-base leading-snug truncate">{product.name}</h3>
        </Link>
        <div className="flex items-center gap-2 mt-2">
          <div className={cn(
            "flex items-center gap-1 text-sm font-semibold text-white px-2 py-0.5 rounded-full",
            product.rating >= 4 ? "bg-green-600" : product.rating >= 3 ? "bg-yellow-500" : "bg-red-500"
          )}>
            <span>{product.rating.toFixed(1)}</span>
            <Star className="h-3 w-3 fill-white" />
          </div>
          <span className="text-sm text-muted-foreground">({product.reviewCount})</span>
        </div>
        <p className="text-lg font-bold mt-2">
          ${product.price.toFixed(2)}
        </p>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <div className="flex gap-2 w-full">
            <Button variant="outline" className="flex-1" onClick={handleAddToCart}>Add to Cart</Button>
            <Button className="flex-1" onClick={handleBuyNow}>Buy Now</Button>
        </div>
      </CardFooter>
    </Card>
  );
}
