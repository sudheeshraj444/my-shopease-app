'use client';

import { useSettingsStore } from '@/lib/settings-store';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

export function OnboardingGuard({ children }: { children: React.ReactNode }) {
  const { isOnboardingComplete } = useSettingsStore();
  const router = useRouter();
  const pathname = usePathname();
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  useEffect(() => {
    if (isClient) {
        if (!isOnboardingComplete && !pathname.startsWith('/welcome')) {
            router.replace('/welcome/language');
        }
    }
  }, [isOnboardingComplete, pathname, router, isClient]);

  if (!isClient || (!isOnboardingComplete && !pathname.startsWith('/welcome'))) {
    // You can return a loading spinner here while the check is happening
    // to prevent a flash of the original content.
    return (
        <div className="flex min-h-screen w-full items-center justify-center">
            {/* You could add a Logo or Loader component here */}
        </div>
    );
  }

  return <>{children}</>;
}
