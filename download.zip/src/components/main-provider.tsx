'use client';

import { ThemeProvider } from '@/components/theme-provider';
import { FirebaseClientProvider } from '@/firebase';
import { Toaster } from '@/components/ui/toaster';
import { OnboardingGuard } from '@/components/shared/onboarding-guard';

export function MainProvider({ children }: { children: React.ReactNode }) {
    return (
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <FirebaseClientProvider>
            <OnboardingGuard>
                {children}
            </OnboardingGuard>
            <Toaster />
          </FirebaseClientProvider>
        </ThemeProvider>
    )
}
