"use client";

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { suggestBestCoupon, SuggestBestCouponOutput } from '@/ai/flows/suggest-best-coupon';
import { Sparkles, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CouponSuggesterProps {
  cartValue: number;
}

export function CouponSuggester({ cartValue }: CouponSuggesterProps) {
  const [suggestion, setSuggestion] = useState<SuggestBestCouponOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSuggestCoupon = async () => {
    setIsLoading(true);
    setSuggestion(null);
    try {
      const result = await suggestBestCoupon({
        cartValue,
        availableCoupons: ['SAVE10', 'FREESHIP', '20OFF50'],
        userLoyaltyPoints: 150,
      });
      setSuggestion(result);
    } catch (error) {
      console.error('Failed to suggest coupon:', error);
      toast({
        variant: 'destructive',
        title: 'Suggestion Failed',
        description: 'Could not get a coupon suggestion at this time.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <Button variant="outline" className="w-full" onClick={handleSuggestCoupon} disabled={isLoading}>
        {isLoading ? (
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
        ) : (
          <Sparkles className="mr-2 h-4 w-4" />
        )}
        Find Best Coupon
      </Button>
      {suggestion && (
        <Alert>
            <Sparkles className="h-4 w-4" />
          <AlertTitle>Best Coupon: {suggestion.bestCoupon}</AlertTitle>
          <AlertDescription>{suggestion.reason}</AlertDescription>
        </Alert>
      )}
    </div>
  );
}
